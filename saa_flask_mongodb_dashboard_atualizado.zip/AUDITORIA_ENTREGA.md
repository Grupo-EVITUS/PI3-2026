# Auditoria da entrega — SAA

Data da auditoria: 2026-10-09

## Conclusão executiva

O pacote contém uma **base Flask + MongoDB funcional em nível de código**, com login interno e CRUD por API. Ele **não deve ser considerado ainda a entrega completa do banco especificada no prompt original**.

Não foram inventados arquivos ou resultados para aparentar conclusão. Os itens abaixo distinguem o que está implementado, parcial ou ausente.

## Matriz contra o prompt original

| Item solicitado | Situação | Evidência / observação |
|---|---|---|
| Modelo conceitual das entidades | Parcial | As entidades aparecem no Model e README, mas não há documento conceitual formal completo. |
| Modelo lógico MongoDB | Parcial | Há collections e referências descritas, mas não há um documento completo de modelagem. |
| Diagrama ER Mermaid | Não entregue | Não existe arquivo `.mmd` ou seção Mermaid no pacote. |
| Script completo de criação do banco | Parcial | `ensure_indexes()` cria índices, mas não há script completo com validators JSON Schema para todas as collections. |
| Chaves e índices | Parcial/entregue | Há índices principais em `models/saa_model.py`; MongoDB usa `_id` e índices únicos. |
| Validadores de domínio | Parcial | Há validações no controller/model; faltam validators MongoDB formais e cobertura completa. |
| Dados fictícios | Não entregue | Não há `seed.py` com alunos, turmas, matrículas, faltas, justificativas e comunicações. |
| Gráfico 1 — faltantes por turma | Parcial | Há agregação por turma no dashboard. |
| Gráfico 2 — faltantes gerais | Parcial | Há total geral e alunos distintos na agregação. |
| Gráfico 3 — presença média por turma | Parcial | Há percentual de presença por turma. |
| Gráfico 4 — presença média geral | Parcial | Há percentual geral ponderado pelas oportunidades. |
| Gráfico 5 — frequência mínima | Não entregue | Existe collection prevista, mas não há consulta implementada comparando aluno/turma/escola ao mínimo. |
| Gráfico 6 — situação das justificativas | Não entregue | Há collection/consulta pendente básica, mas não há gráfico/indicador completo. |
| Consultas parametrizáveis completas | Parcial | Dashboard aceita filtros; faltam todas as consultas documentadas do prompt. |
| CRUD da AOE | Parcial/entregue em API | Há endpoints genéricos protegidos para alunos, turmas, responsáveis, matrículas e frequência. Não há telas CRUD completas. |
| Histórico escolar | Parcial | Matrículas e frequência não são apagadas; faltam consultas históricas completas. |
| Justificativas | Parcial | Há formulário público, token hash/expiração/uso único e persistência básica. |
| Comunicação por e-mail | Não entregue | Não há integração com SMTP/SES/SendGrid nem collection de tentativas implementada no fluxo. |
| Login da AOE | Entregue em nível de código | `/login`, sessão, hash de senha e perfis permitidos. |
| Permissões detalhadas por perfil | Parcial | Perfis são reconhecidos, mas as diferenças de autorização ainda não estão aplicadas em todas as rotas. |
| Testes de integridade e indicadores | Não entregue | Há somente teste básico de rotas; não há suíte contra MongoDB nem resultados esperados dos indicadores. |
| Orientações de integração | Parcial | README contém execução, rotas e variáveis; falta documentação completa de contrato e implantação. |

## Arquivos incluídos nesta versão

- `app.py` — aplicação Flask, login interno, rotas públicas de justificativa e API CRUD.
- `config.py` — variáveis de conexão e configuração.
- `models/saa_model.py` — conexão, índices, agregações, autenticação e tokens.
- `controllers/dashboard_controller.py` — filtros e preparação do dashboard.
- `controllers/aoe_crud_controller.py` — transformação e validação básica do CRUD.
- `scripts/create_user.py` — cadastro seguro de usuários AOE/COORDINATION/ADMIN.
- `views/templates/aoe_login.html` — login interno.
- `views/templates/dashboard.html` — dashboard inicial.
- `views/templates/students.html` — listagem simples.
- `views/templates/justification.html` — formulário público dos responsáveis.
- `views/templates/justification_success.html` — confirmação do envio.
- `tests/test_app.py` — teste básico de mapeamento de rotas.
- `requirements.txt` — dependências.
- `README.md` — instruções atuais.

## Pendências necessárias para declarar a entrega completa

1. Definir e confirmar regras ainda abertas: frequência diária/aula, período letivo, status de justificativa, percentual mínimo e e-mail.
2. Criar `seed.py` completo com dados fictícios e casos-limite.
3. Criar validators JSON Schema e script de inicialização de todas as collections.
4. Criar diagrama Mermaid e dicionário de dados formal.
5. Implementar os seis indicadores e consultas documentadas.
6. Implementar comunicações de e-mail e auditoria de envio.
7. Completar permissões por perfil.
8. Criar testes de integração e testar com MongoDB ativo.
9. Criar telas HTML CRUD, se a entrega exigir interface visual além da API.

## Verificação executada

A sintaxe dos módulos Python foi validada com `python3 -m py_compile`. Não foi possível afirmar testes de integração porque não há MongoDB configurado/ativo nesta auditoria e as dependências podem ainda não estar instaladas no ambiente.
