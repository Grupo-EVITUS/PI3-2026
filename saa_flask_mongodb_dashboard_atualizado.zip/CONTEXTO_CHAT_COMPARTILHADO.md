# Contexto consolidado do chat compartilhado

Fonte consultada: https://chatgpt.com/share/6ac97e3e-91bc-83e8-b428-9c8461485bce
Data de consolidação: 2026-10-09

Este arquivo registra as decisões úteis do chat compartilhado para continuidade do projeto SAA. Ele é um resumo de requisitos, não substitui validação da equipe.

## Produto

SAA — Sistema de Ausência de Alunos.

Problema: professores informam manualmente ausências no grupo interno da escola, a AOE registra as ocorrências e os responsáveis podem não saber que o aluno não entrou em sala. O sistema deve centralizar o registro, comunicar por e-mail e receber justificativas.

## Participantes e usuários

- Professores: identificam ausentes e comunicam a AOE pelo grupo interno de WhatsApp; não são usuários diretos da aplicação na primeira versão.
- AOE / responsável pelo registro: faz login, localiza turma/alunos, registra ausências e acompanha o processamento da comunicação.
- Pais/responsáveis: não possuem login; recebem e-mail com ocorrência e link seguro, acessam o formulário, escolhem o motivo, explicam “Outro” e recebem confirmação.
- Coordenação: faz login, consulta ocorrências, pendências, justificativas respondidas, pesquisa e histórico.
- Diretor: stakeholder institucional; perfil de acesso ainda precisa ser confirmado.

O WhatsApp não será integrado ao SAA. Ele é somente canal interno Professora → AOE.

## Fluxo principal

1. Professora identifica os alunos ausentes.
2. Professora informa os nomes no grupo interno.
3. AOE acessa o SAA.
4. AOE localiza a turma e os alunos.
5. AOE registra uma ou mais ausências e a data.
6. Sistema identifica os responsáveis vinculados.
7. Sistema gera e envia e-mail com dados da ocorrência e link do formulário.
8. Responsável acessa o link sem conta.
9. Responsável seleciona motivo ou “Outro” com explicação.
10. Sistema registra data/hora e muda o status de Pendente para Respondida.
11. Coordenação acompanha ocorrências, pendências, respostas e histórico.

## Requisitos funcionais consolidados

- RF01 cadastrar alunos.
- RF02 cadastrar turmas.
- RF03 cadastrar responsáveis.
- RF04 cadastrar e-mail dos responsáveis.
- RF05 relacionar aluno, turma e responsável.
- RF06 localizar turma.
- RF07 localizar alunos da turma.
- RF08 registrar ausência de um ou mais alunos.
- RF09 registrar data da ausência.
- RF10 identificar responsável vinculado.
- RF11 gerar mensagem automática.
- RF12 incluir dados do aluno e ocorrência.
- RF13 enviar e-mail.
- RF14 inserir link de justificativa no e-mail.
- RF15 acessar formulário pelo link.
- RF16 identificar a ocorrência no formulário.
- RF17 oferecer motivos predefinidos.
- RF18 oferecer “Outro”.
- RF19 exigir explicação em “Outro”.
- RF20 permitir envio.
- RF21 registrar justificativa.
- RF22 registrar data/hora.
- RF23 alterar status Pendente → Respondida.
- RF24 confirmar o envio.
- RF25 coordenação visualizar ocorrências.
- RF26 visualizar pendentes.
- RF27 visualizar respondidas.
- RF28 pesquisar por aluno.
- RF29 pesquisar por turma.
- RF30 pesquisar por data.
- RF31 consultar histórico do aluno.

## Requisitos não funcionais

- RNF01 usabilidade.
- RNF02 responsividade para computador, tablet e celular.
- RNF03 desempenho adequado.
- RNF04 segurança e restrição por perfil.
- RNF05 privacidade de dados pessoais.
- RNF06 confiabilidade e preservação dos registros.
- RNF07 disponibilidade conforme necessidade escolar.
- RNF08 integridade, sem duplicidades e referências incorretas.
- RNF09 compatibilidade com Chrome, Edge e Firefox.
- RNF10 manutenibilidade.
- RNF11 controle de acesso por perfil.
- RNF12 registro de operações relevantes.

## Escopo do MVP identificado no chat

Dentro do foco inicial:

- cadastro de alunos, turmas e responsáveis;
- vínculo entre aluno, turma e responsável;
- registro de ausências;
- envio de e-mail;
- link/formulário de justificativa;
- registro e status da justificativa;
- acompanhamento pela coordenação.

Fora ou posterior ao MVP original:

- WhatsApp/SMS/push integrados;
- aplicativo mobile;
- integrações externas;
- automações avançadas;
- relatórios e gráficos, embora o prompt técnico posterior tenha acrescentado dashboard como requisito do banco.

## Regras técnicas do prompt posterior

- MongoDB foi escolhido para esta implementação, embora o prompt original ainda contenha texto de SQL/MariaDB/MySQL que deve ser adaptado para collections, documentos, índices, validators e aggregation pipelines.
- Frequência diária ou por aula precisa ser confirmada; a base atual usa frequência diária como premissa.
- Falta justificada continua sendo ausência para cálculo, salvo regra oficial diferente.
- Não contar duas vezes o mesmo aluno no indicador de alunos faltantes distintos.
- Separar alunos faltantes distintos, ocorrências totais e registros de frequência considerados no cálculo de presença.
- Não incluir registros não lançados no denominador.
- Preservar histórico de matrículas e frequência.
- Percentual mínimo obrigatório deve ser configurável, não fixado sem confirmação.
- Comunicações devem distinguir pendente, enviado e falha; e-mail enviado não significa e-mail lido.

## Arquitetura atual do código

- Python + Flask + PyMongo + MongoDB + Plotly.
- AOE/coordenação/admin fazem login em `/login`.
- Pais/responsáveis não fazem login; usam `/justify/<token>`.
- API CRUD protegida em `/api/students`, `/api/classes`, `/api/guardians`, `/api/enrollments` e `/api/attendance`.
- O token público deve ser armazenado apenas como hash, com expiração e uso único.

## Decisões que ainda precisam ser confirmadas

1. Frequência diária ou por aula.
2. Perfil e permissões exatas do diretor.
3. Status da justificativa: apenas Pendente/Respondida ou também Aprovada/Rejeitada.
4. Percentual mínimo oficial e sua variação por etapa/período.
5. Provedor de e-mail.
6. Política de múltiplos responsáveis e contatos principais.
7. Período letivo e regras de mudança de turma.
8. Necessidade de confirmação técnica de abertura/leitura do e-mail.

## Histórico documental

O chat compartilhado também contém material de Sprint Review e levantamento de personas/requisitos. Esses registros indicam que o projeto estava inicialmente em discovery e que modelagem, login e implementação pertenciam a etapas posteriores. Não tratar os artefatos de discovery como prova de funcionalidades já implementadas.

## Regra adicional do anexo `pasted_content_2.txt`

Ao localizar um aluno para disparar uma notificação, o sistema deve puxar automaticamente o nome cadastrado, as ausências registradas, os responsáveis vinculados e os e-mails válidos. A mensagem deve ser montada com nome do aluno, data da ausência, informações complementares, texto predefinido e link individual de justificativa. A comunicação só pode ser enfileirada quando existir pelo menos um responsável com e-mail válido. O histórico deve guardar aluno, responsável, e-mail, envio, entrega, abertura/acesso, status e conteúdo. Reenvio deve gerar uma nova solicitação e todos os eventos devem ficar auditáveis.
