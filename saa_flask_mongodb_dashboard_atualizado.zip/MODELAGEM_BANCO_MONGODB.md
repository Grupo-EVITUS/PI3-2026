# Modelagem do Banco MongoDB — SAA

**Sistema:** SAA — Sistema de Ausência de Alunos  
**Tecnologia:** MongoDB + PyMongo  
**Aplicação:** Python + Flask  
**Granularidade adotada:** frequência diária, uma ocorrência por matrícula e data  
**Versão da documentação:** 1.0 — 10/10/2026

## 1. Objetivo

Esta documentação define a modelagem de dados do SAA para suportar o cadastro escolar, o registro de frequência, a comunicação de ausências aos responsáveis, o formulário público de justificativa, o histórico de notificações e os indicadores do dashboard.

O desenho prioriza referências por `ObjectId`, preservação do histórico, prevenção de duplicidades e consultas analíticas sem multiplicação indevida de registros por causa de múltiplos responsáveis ou justificativas.

> O WhatsApp não é uma collection nem uma integração do SAA. Ele permanece como canal interno entre professora e AOE.

## 2. Premissas e decisões

| Tema | Decisão adotada | Observação |
|---|---|---|
| Banco | MongoDB | Documentos relacionados usam `ObjectId`. |
| Frequência | Diária | Um registro por matrícula e data. Não representa cinco aulas como cinco faltas. |
| Ausência justificada | Continua sendo ausência | A justificativa é informação complementar e não altera automaticamente o status da frequência. |
| Pais/responsáveis | Sem login | Recebem link seguro, com hash, expiração e uso único. |
| Usuários internos | AOE, COORDINATION e ADMIN | Senhas somente com hash. |
| Comunicação | E-mail | O sistema registra pendente, enviado, entregue, aberto e falha quando o provedor informar. |
| Histórico | Arquivar em vez de apagar | Matrículas, frequências e notificações devem permanecer auditáveis. |
| Indicadores | Agregações calculadas | Totais e percentuais não devem ser armazenados como fonte oficial. |

### Decisões ainda pendentes

1. Confirmar se a escola futuramente precisará controlar frequência por aula.
2. Confirmar percentual mínimo obrigatório por etapa e período letivo.
3. Confirmar permissões detalhadas do perfil ADMIN e eventual perfil DIRETOR.
4. Escolher provedor de e-mail e eventos de webhook.
5. Confirmar se justificativas terão apenas `PENDING/RESPONDED` ou também `APPROVED/REJECTED`.
6. Confirmar política para múltiplos responsáveis e contato principal.

## 3. Modelo conceitual

O relacionamento principal é:

```text
Aluno
  └── Matrícula ── Turma / Período letivo
        └── Frequência diária
              └── Notificação de ausência ── Responsável
                    ├── Link seguro de justificativa
                    └── Justificativa enviada
```

Um aluno pode ter várias matrículas ao longo dos períodos. Uma matrícula pertence a uma turma e possui vários registros de frequência. Um aluno pode ter vários responsáveis, e um responsável pode estar associado a vários alunos; por isso existe a collection associativa `student_guardians`.

## 4. Diagrama ER

O diagrama completo está em [`modelo_er_saa.mmd`](modelo_er_saa.mmd) e também em [`modelo_er_saa.png`](modelo_er_saa.png).

```mermaid
erDiagram
    STUDENTS ||--o{ ENROLLMENTS : possui
    CLASSES ||--o{ ENROLLMENTS : recebe
    ACADEMIC_PERIODS ||--o{ ENROLLMENTS : organiza
    STUDENTS ||--o{ STUDENT_GUARDIANS : possui
    GUARDIANS ||--o{ STUDENT_GUARDIANS : acompanha
    ENROLLMENTS ||--o{ ATTENDANCE_RECORDS : registra
    USERS ||--o{ ATTENDANCE_RECORDS : lancamento
    ATTENDANCE_RECORDS ||--o{ EMAIL_NOTIFICATIONS : comunica
    GUARDIANS ||--o{ EMAIL_NOTIFICATIONS : recebe
    STUDENTS ||--o{ EMAIL_NOTIFICATIONS : identifica
    ATTENDANCE_RECORDS ||--o{ JUSTIFICATION_LINKS : disponibiliza
    GUARDIANS ||--o{ JUSTIFICATION_LINKS : utiliza
    ATTENDANCE_RECORDS ||--o| JUSTIFICATIONS : pode_ter
    GUARDIANS ||--o{ JUSTIFICATIONS : envia
    JUSTIFICATION_REASONS ||--o{ JUSTIFICATIONS : classifica
    USERS ||--o{ EMAIL_NOTIFICATIONS : solicita
    EMAIL_NOTIFICATIONS ||--o{ AUDIT_EVENTS : audita
```

## 5. Collections e documentos

### 5.1 `students`

Cadastro principal do aluno. Não usar o nome como chave.

```json
{
  "_id": { "$oid": "..." },
  "name": "Ana Beatriz Souza",
  "school_id": "MAT-001",
  "active": true,
  "created_at": { "$date": "2026-01-10T12:00:00Z" },
  "updated_at": { "$date": "2026-01-10T12:00:00Z" }
}
```

| Campo | Tipo | Obrigatório | Regra |
|---|---|---:|---|
| `_id` | ObjectId | Sim | Chave MongoDB. |
| `name` | string | Sim | Nome completo; não é chave. |
| `school_id` | string | Não | Matrícula/identificador escolar; único quando informado. |
| `active` | boolean | Sim | Inativação lógica. |
| `created_at`, `updated_at` | date | Sim | Auditoria básica. |

### 5.2 `classes`

Representa a turma, série, turno e período de funcionamento.

```json
{
  "_id": { "$oid": "..." },
  "name": "6º Ano A",
  "code": "6A",
  "grade": "6º ano",
  "shift": "MORNING",
  "academic_period_id": { "$oid": "..." },
  "active": true,
  "created_at": { "$date": "2026-01-05T12:00:00Z" },
  "updated_at": { "$date": "2026-01-05T12:00:00Z" }
}
```

`shift` deve usar domínio controlado, por exemplo `MORNING`, `AFTERNOON` ou `NIGHT`.

### 5.3 `academic_periods` — recomendada

Collection recomendada para não deixar o período letivo apenas como texto repetido.

```json
{
  "_id": { "$oid": "..." },
  "name": "Ano letivo 2026",
  "code": "2026",
  "start_date": { "$date": "2026-02-01T00:00:00Z" },
  "end_date": { "$date": "2026-12-20T00:00:00Z" },
  "active": true
}
```

### 5.4 `enrollments`

É a matrícula/vínculo histórico entre aluno, turma e período. A frequência referencia a matrícula, e não apenas o aluno, para preservar mudanças de turma.

```json
{
  "_id": { "$oid": "..." },
  "student_id": { "$oid": "..." },
  "class_id": { "$oid": "..." },
  "academic_period_id": { "$oid": "..." },
  "start_date": { "$date": "2026-02-01T00:00:00Z" },
  "end_date": null,
  "active": true,
  "created_at": { "$date": "2026-02-01T12:00:00Z" }
}
```

Restrição principal: não permitir duas matrículas para o mesmo aluno no mesmo período letivo. Se a regra permitir transferência dentro do mesmo período, substituir essa unicidade por uma regra de vigência sem sobreposição.

### 5.5 `guardians`

Cadastro único do responsável. O e-mail é normalizado para busca e unicidade.

```json
{
  "_id": { "$oid": "..." },
  "name": "Carlos Souza",
  "email": "Carlos.Souza@exemplo.com",
  "email_normalized": "carlos.souza@exemplo.com",
  "phone": null,
  "active": true,
  "created_at": { "$date": "2026-02-01T12:00:00Z" },
  "updated_at": { "$date": "2026-02-01T12:00:00Z" }
}
```

### 5.6 `student_guardians`

Collection associativa para relação N:N entre alunos e responsáveis.

```json
{
  "_id": { "$oid": "..." },
  "student_id": { "$oid": "..." },
  "guardian_id": { "$oid": "..." },
  "relationship": "PAI",
  "is_primary": true,
  "receives_absence_notifications": true,
  "active": true,
  "created_at": { "$date": "2026-02-01T12:00:00Z" }
}
```

Não duplicar nome ou e-mail do responsável nesta collection. O e-mail é obtido por `$lookup` em `guardians`.

### 5.7 `attendance_records`

Fonte oficial da frequência diária.

```json
{
  "_id": { "$oid": "..." },
  "enrollment_id": { "$oid": "..." },
  "date": { "$date": "2026-10-09T00:00:00Z" },
  "status": "ABSENT",
  "registered_by": { "$oid": "..." },
  "notes": "Ausência informada pela professora",
  "created_at": { "$date": "2026-10-09T12:00:00Z" },
  "updated_at": { "$date": "2026-10-09T12:00:00Z" }
}
```

Domínio de `status`:

| Status | Entra no denominador? | Conta como ausência? |
|---|---:|---:|
| `PRESENT` | Sim | Não |
| `ABSENT` | Sim | Sim |
| `EXCUSED` | Conforme regra oficial; na premissa atual, sim | Sim |
| `NOT_REGISTERED` | Não | Não |

A constraint essencial é unicidade de `enrollment_id + date`.

### 5.8 `justification_reasons`

Motivos administráveis sem alterar a collection de justificativas.

```json
{
  "_id": { "$oid": "..." },
  "code": "MEDICAL",
  "label": "Consulta médica",
  "requires_explanation": false,
  "active": true,
  "sort_order": 2
}
```

O motivo `OTHER` deve possuir `requires_explanation: true`.

### 5.9 `justifications`

Resposta do responsável relacionada à ocorrência correta.

```json
{
  "_id": { "$oid": "..." },
  "attendance_id": { "$oid": "..." },
  "guardian_id": { "$oid": "..." },
  "reason_code": "MEDICAL",
  "explanation": "Consulta médica no período da manhã.",
  "status": "RESPONDED",
  "submitted_at": { "$date": "2026-10-09T18:30:00Z" },
  "created_at": { "$date": "2026-10-09T18:30:00Z" },
  "updated_at": { "$date": "2026-10-09T18:30:00Z" }
}
```

A ocorrência continua sendo `ABSENT`; a justificativa não deve alterar retroativamente o registro de frequência.

### 5.10 `justification_links`

Token público de uso único. O token puro nunca é salvo.

```json
{
  "_id": { "$oid": "..." },
  "token_hash": "sha256-do-token",
  "attendance_id": { "$oid": "..." },
  "guardian_id": { "$oid": "..." },
  "notification_id": { "$oid": "..." },
  "expires_at": { "$date": "2026-11-08T12:00:00Z" },
  "used_at": null,
  "active": true,
  "created_at": { "$date": "2026-10-09T12:00:00Z" }
}
```

O link só é válido se `active: true`, `expires_at > now` e `used_at` não existir.

### 5.11 `email_notifications`

Histórico e rastreabilidade da comunicação. Este documento guarda o conteúdo efetivamente montado, inclusive o endereço usado no envio.

```json
{
  "_id": { "$oid": "..." },
  "student_id": { "$oid": "..." },
  "attendance_id": { "$oid": "..." },
  "guardian_id": { "$oid": "..." },
  "recipient_email": "carlos.souza@exemplo.com",
  "subject": "Comunicado de ausência escolar",
  "body": "Olá... Link: https://saa.exemplo/justify/token",
  "justification_url": "https://saa.exemplo/justify/token",
  "status": "OPENED",
  "provider_message_id": "provider-id",
  "attempted_at": { "$date": "2026-10-09T12:01:00Z" },
  "delivered_at": { "$date": "2026-10-09T12:01:04Z" },
  "opened_at": { "$date": "2026-10-09T13:20:00Z" },
  "open_count": 1,
  "failure_detail": null,
  "created_by": { "$oid": "..." },
  "created_at": { "$date": "2026-10-09T12:00:00Z" },
  "updated_at": { "$date": "2026-10-09T13:20:00Z" }
}
```

Status recomendado: `PENDING`, `SENT`, `DELIVERED`, `OPENED`, `FAILED`. Abertura só deve ser registrada quando o provedor informar o evento; SMTP isolado não confirma leitura.

### 5.12 `message_templates` — recomendada

Permite editar a mensagem padrão sem alterar código.

```json
{
  "_id": { "$oid": "..." },
  "code": "ABSENCE_DEFAULT",
  "subject": "Comunicado de ausência escolar",
  "body": "Olá, {{guardian_name}}. Registramos uma ausência de {{student_name}} em {{absence_date}}. {{justification_url}}",
  "variables": ["guardian_name", "student_name", "absence_date", "justification_url"],
  "active": true,
  "version": 1,
  "created_at": { "$date": "2026-01-01T12:00:00Z" }
}
```

### 5.13 `users`

Usuários internos que fazem login.

```json
{
  "_id": { "$oid": "..." },
  "name": "AOE da Escola",
  "email": "aoe@escola.com",
  "email_normalized": "aoe@escola.com",
  "password_hash": "hash-werkzeug",
  "profile": "AOE",
  "active": true,
  "last_login_at": { "$date": "2026-10-09T12:00:00Z" },
  "created_at": { "$date": "2026-01-01T12:00:00Z" },
  "updated_at": { "$date": "2026-01-01T12:00:00Z" }
}
```

Perfis atuais: `AOE`, `COORDINATION`, `ADMIN`. Nunca guardar senha em texto puro.

### 5.14 `attendance_policies`

Configuração do percentual mínimo obrigatório.

```json
{
  "_id": { "$oid": "..." },
  "academic_period_id": { "$oid": "..." },
  "scope": "SCHOOL",
  "minimum_presence_percent": 75,
  "valid_from": { "$date": "2026-02-01T00:00:00Z" },
  "valid_to": { "$date": "2026-12-20T00:00:00Z" },
  "active": true,
  "updated_by": { "$oid": "..." }
}
```

O valor `75` é apenas exemplo de configuração e não deve ser considerado regra legal sem validação da escola.

### 5.15 `audit_events` — recomendada

Necessária para cumprir a auditoria completa dos eventos de envio, entrega, abertura, acesso e alterações internas.

```json
{
  "_id": { "$oid": "..." },
  "entity": "EMAIL_NOTIFICATION",
  "entity_id": { "$oid": "..." },
  "event": "OPENED",
  "actor_type": "PROVIDER",
  "actor_id": "provider-message-id",
  "metadata": { "ip": "...", "user_agent": "..." },
  "created_at": { "$date": "2026-10-09T13:20:00Z" }
}
```

Não guardar credenciais ou segredos no campo `metadata`.

## 6. Índices recomendados

```javascript
// Cadastros
 db.students.createIndex({ school_id: 1 }, { unique: true, sparse: true })
 db.guardians.createIndex({ email_normalized: 1 }, { unique: true, sparse: true })
 db.classes.createIndex({ academic_period_id: 1, code: 1 }, { unique: true })
 db.users.createIndex({ email_normalized: 1 }, { unique: true })

// Histórico escolar
 db.enrollments.createIndex({ student_id: 1, academic_period_id: 1 }, { unique: true })
 db.enrollments.createIndex({ class_id: 1, academic_period_id: 1 })
 db.attendance_records.createIndex({ enrollment_id: 1, date: 1 }, { unique: true })
 db.attendance_records.createIndex({ date: 1, status: 1 })

// Relações e justificativas
 db.student_guardians.createIndex({ student_id: 1, guardian_id: 1 }, { unique: true })
 db.justifications.createIndex({ attendance_id: 1 }, { unique: true })
 db.justifications.createIndex({ status: 1, submitted_at: -1 })
 db.justification_reasons.createIndex({ code: 1 }, { unique: true })

// Tokens e comunicação
 db.justification_links.createIndex({ token_hash: 1 }, { unique: true })
 db.justification_links.createIndex({ expires_at: 1, used_at: 1 })
 db.email_notifications.createIndex({ attendance_id: 1, guardian_id: 1 })
 db.email_notifications.createIndex({ status: 1, attempted_at: -1 })
 db.email_notifications.createIndex({ student_id: 1, created_at: -1 })
 db.audit_events.createIndex({ entity: 1, entity_id: 1, created_at: -1 })
```

## 7. Regras de integridade

1. Todo `attendance_records.enrollment_id` deve referenciar uma matrícula existente.
2. Uma matrícula deve referenciar aluno, turma e período válidos.
3. Não permitir duas frequências para a mesma matrícula na mesma data.
4. Não usar nome do aluno como relacionamento.
5. Não apagar frequência ou matrícula histórica; arquivar quando necessário.
6. Uma notificação só pode ser criada se existir responsável vinculado com e-mail válido.
7. O `recipient_email` é um snapshot do endereço usado no envio, mas a fonte cadastral continua sendo `guardians`.
8. O link público deve ser individual, expirável, armazenado por hash e de uso único.
9. A explicação é obrigatória quando o motivo for `OTHER`.
10. Abertura do e-mail só é confirmada por evento confiável do provedor.
11. Reenvio deve criar uma nova notificação e um novo link, preservando o histórico anterior.
12. O dashboard deve separar alunos distintos, ocorrências e registros de frequência considerados no cálculo de presença.

## 8. Fluxo transacional da notificação

A operação de disparo deve seguir esta ordem:

1. Receber `student_id` e `attendance_id`.
2. Buscar aluno e validar que está ativo.
3. Buscar a ausência e validar que pertence a uma matrícula do aluno.
4. Buscar responsáveis vinculados e filtrar e-mails válidos.
5. Interromper se não houver destinatário.
6. Carregar `message_templates` ativo.
7. Gerar token, salvar apenas seu hash e montar a URL.
8. Substituir `student_name`, `absence_date`, `absence_details` e `justification_url`.
9. Criar `email_notifications` com `PENDING`.
10. Enviar ao provedor.
11. Atualizar para `SENT` ou `FAILED` com o identificador do provedor.
12. Receber webhooks e atualizar `DELIVERED`, `OPENED` ou `FAILED`.
13. Registrar cada transição em `audit_events`.

A criação do link e da notificação deve ocorrer em uma transação MongoDB quando o ambiente utilizar replica set. Se não houver transação disponível, registrar uma rotina de compensação para não deixar link órfão.

## 9. Consultas do dashboard

### Alunos faltantes distintos por turma

```javascript
db.attendance_records.aggregate([
  { $match: { date: { $gte: ISODate("2026-10-01"), $lte: ISODate("2026-10-31") }, status: "ABSENT" } },
  { $lookup: { from: "enrollments", localField: "enrollment_id", foreignField: "_id", as: "enrollment" } },
  { $unwind: "$enrollment" },
  { $lookup: { from: "classes", localField: "enrollment.class_id", foreignField: "_id", as: "class" } },
  { $unwind: "$class" },
  { $group: { _id: "$class._id", class_name: { $first: "$class.name" }, students: { $addToSet: "$enrollment.student_id" }, absence_occurrences: { $sum: 1 } } },
  { $project: { _id: 0, class_name: 1, distinct_absent_students: { $size: "$students" }, absence_occurrences: 1 } },
  { $sort: { class_name: 1 } }
])
```

### Presença geral correta

A presença geral deve ser calculada com totais, e não pela média simples dos percentuais das turmas:

```text
presença geral = soma de PRESENT / soma de PRESENT + ABSENT × 100
```

### Média mensal de ausências por aluno

```text
média mensal = ocorrências ABSENT no mês / alunos distintos faltantes no mês
```

### Comparação com frequência obrigatória

```text
frequência do aluno = PRESENT / (PRESENT + ABSENT) × 100
situação = frequência do aluno >= política.minimum_presence_percent
```

`NOT_REGISTERED` não participa do denominador.

## 10. API relacionada ao modelo

| Método | Rota | Finalidade |
|---|---|---|
| `GET` | `/api/students` | Listar alunos ativos. |
| `GET` | `/api/classes` | Listar turmas. |
| `GET` | `/api/guardians` | Listar responsáveis. |
| `GET` | `/api/enrollments` | Listar matrículas. |
| `GET` | `/api/attendance` | Listar frequências. |
| `GET` | `/api/notification-context?student_id=...` | Puxar aluno, ausências e responsáveis com e-mail. |
| `POST` | `/api/webhooks/email` | Receber eventos do provedor. |
| `GET/POST` | `/email-dispatch` | Tela interna de composição e fila. |
| `GET/POST` | `/justify/<token>` | Formulário público sem login. |

## 11. Implementado versus recomendado

### Implementado no código atual

- collections principais de alunos, turmas, responsáveis, matrículas, frequência, justificativas, links, usuários e notificações;
- índices básicos;
- frequência diária;
- autenticação interna;
- token com hash, expiração e uso único;
- dashboard com agregações por turma, geral, mês e ano;
- busca de contexto do aluno para disparo;
- webhook de eventos de e-mail;
- tela de composição e histórico de comunicações.

### Recomendado para concluir a versão de produção

- criar `academic_periods`, `message_templates` e `audit_events` como collections formais;
- adicionar JSON Schema Validators em todas as collections;
- integrar um provedor real de e-mail;
- persistir cada evento de webhook em `audit_events`;
- configurar transações MongoDB com replica set;
- criar seed fictício completo e testes de agregação;
- completar as telas CRUD de turmas, responsáveis, matrículas e frequência;
- definir política oficial de retenção e privacidade.

## 12. Segurança e privacidade

- Senhas devem usar hash forte, nunca texto puro.
- Tokens públicos devem ser armazenados com SHA-256 ou mecanismo equivalente.
- Webhooks devem validar segredo ou assinatura do provedor.
- Não guardar credenciais de e-mail no MongoDB.
- Restringir o dashboard a usuários internos autenticados.
- Não expor dados de um aluno ao responsável de outro aluno.
- Aplicar princípio de menor privilégio por perfil.
- Registrar alterações relevantes para auditoria.
- Usar HTTPS em qualquer ambiente acessível externamente.

## 13. Checklist de validação

- [ ] A mesma matrícula não possui duas frequências para a mesma data.
- [ ] Um aluno com cinco faltas aparece uma vez no indicador de alunos distintos.
- [ ] As cinco faltas continuam aparecendo como cinco ocorrências.
- [ ] Responsáveis múltiplos não multiplicam o total do dashboard.
- [ ] Uma falta justificada permanece ausência.
- [ ] `NOT_REGISTERED` não entra no denominador.
- [ ] Mudança de turma não altera o histórico antigo.
- [ ] O link expirado ou utilizado retorna erro.
- [ ] O envio sem e-mail válido é recusado.
- [ ] O webhook sem segredo é recusado.
- [ ] O evento `OPENED` registra data/hora e contador.
- [ ] O reenvio gera nova notificação e novo link.

## 14. Conclusão

A estrutura recomendada separa corretamente cadastro, vínculo escolar, frequência, justificativa e comunicação. As referências por `ObjectId` preservam o histórico e as agregações evitam os erros mais comuns: contar um aluno várias vezes, multiplicar faltas por responsáveis ou calcular a média geral como média simples das turmas.
