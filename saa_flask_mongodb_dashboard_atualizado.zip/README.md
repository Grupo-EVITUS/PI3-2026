# SAA — Flask + MongoDB

Base inicial do Sistema de Ausência de Alunos usando **Flask**, **PyMongo**, **MongoDB** e **Plotly**.

## Relação com o guia

O guia autoriza Flask no Exercício 13 do Nível 3: a rota Flask substitui `view_renderer.py` e serve o dashboard dinamicamente. Nesta adaptação, a coleção de vendas foi substituída pelo domínio do SAA.

## Premissas atuais

- Frequência **diária**: um registro por matrícula e data.
- `PRESENT` e `ABSENT` são registros de frequência considerados no cálculo; `NOT_REGISTERED` não entra nos cálculos. Esse denominador é técnico e não aparece como indicador na tela.
- Falta justificada continua sendo ausência para o dashboard.
- O histórico é preservado por `enrollments`; não se deve apagar registros históricos.
- A AOE, a coordenação ou o administrador possuem área autenticada por e-mail e senha; a senha é armazenada somente como hash.
- Pais e responsáveis **não possuem login** nesta arquitetura. Eles recebem um link único e temporário junto com o comunicado de falta.
- O link público é validado por hash, expiração e uso único; ele permite apenas enviar a justificativa da ocorrência vinculada.
- O percentual mínimo obrigatório será configurado em `attendance_policies` quando a regra da escola for confirmada.

## Execução

```bash
cd saa_flask_mongodb
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export MONGO_URI='mongodb://localhost:27017/'
export MONGO_DB='saa'
python app.py
```

Acesse `http://localhost:5000/dashboard`.

## Estrutura MVC

- `models/saa_model.py`: acesso ao MongoDB, índices e pipelines.
- `controllers/dashboard_controller.py`: valida filtros e coordena consultas.
- `app.py`: rotas Flask e orquestração.
- `views/templates/`: dashboard, alunos e formulário de justificativa.
- `CONTEXTO_CHAT_COMPARTILHADO.md`: decisões, personas e requisitos consolidados do link fornecido.
- `MODELAGEM_BANCO_MONGODB.md`: documentação técnica das collections, relacionamentos, índices, regras e agregações.
- `modelo_er_saa.mmd` / `modelo_er_saa.png`: diagrama de entidades e relacionamentos.

O dashboard também apresenta gráficos de linha com a **média mensal** e a **média anual de ausências por aluno**. A média é calculada como `ocorrências de ausência do período ÷ alunos distintos faltantes no período`; os filtros de data, turma e turno são aplicados antes da agregação.

## Direção visual

O frontend usa uma linguagem visual inspirada nas referências públicas da Sala do Futuro: azul-marinho como base, azul vivo para ações, superfícies claras, cards arredondados, navegação lateral e acentos verdes, roxos e vermelhos para estados e indicadores. O código não utiliza logotipo ou asset proprietário da Sala do Futuro; trata-se de uma adaptação visual para o SAA.

## Comunicação e confirmação de abertura

A tela `/email-dispatch` coloca a comunicação em `PENDING` e mostra o histórico. A API não pode descobrir uma abertura apenas pelo SMTP: a confirmação de abertura depende de um provedor com rastreamento e webhook. O endpoint `POST /api/webhooks/email` recebe eventos `SENT`, `DELIVERED`, `OPENED` ou `FAILED`, autenticados por `X-Email-Webhook-Secret`, e atualiza `status`, `opened_at`, `open_count` e `failure_detail`. Portanto, o sistema diferencia corretamente “enviado”, “entregue” e “aberto”; “aberto” só será preenchido quando o provedor confirmar o evento.

## Acesso interno e formulário dos responsáveis

Rotas disponíveis:

- `GET/POST /login`: autenticação da AOE, coordenação ou administração.
- `POST /logout`: encerra a sessão interna.
- `GET /dashboard`: dashboard protegido para usuários internos.
- `GET /justify/<token>`: formulário público recebido pelo responsável no comunicado.
- `POST /justify/<token>`: envia a justificativa usando o token, sem conta ou senha.

### CRUD protegido da AOE

Todos os endpoints abaixo exigem sessão interna autenticada:

| Recurso | Listar | Criar | Consultar | Atualizar | Arquivar |
|---|---|---|---|---|---|
| Alunos | `GET /api/students` | `POST /api/students` | `GET /api/students/{id}` | `PATCH /api/students/{id}` | `DELETE /api/students/{id}` |
| Turmas | `GET /api/classes` | `POST /api/classes` | `GET /api/classes/{id}` | `PATCH /api/classes/{id}` | `DELETE /api/classes/{id}` |
| Responsáveis | `GET /api/guardians` | `POST /api/guardians` | `GET /api/guardians/{id}` | `PATCH /api/guardians/{id}` | `DELETE /api/guardians/{id}` |
| Matrículas | `GET /api/enrollments` | `POST /api/enrollments` | `GET /api/enrollments/{id}` | `PATCH /api/enrollments/{id}` | Não apagar histórico |
| Frequência | `GET /api/attendance` | `POST /api/attendance` | `GET /api/attendance/{id}` | `PATCH /api/attendance/{id}` | Não apagar histórico |

Os `DELETE` de cadastros são arquivamentos (`active=false`). Frequências e matrículas não são apagadas para preservar o histórico escolar.

Exemplo para criar um aluno:

```bash
curl -b cookies.txt -X POST http://localhost:5000/api/students \
  -H 'Content-Type: application/json' \
  -d '{"name":"Aluno Fictício","school_id":"MAT-001"}'
```

A collection `users` deve conter `email_normalized`, `password_hash`, `profile`, `active`, `created_at` e `updated_at`. Para criar uma conta interna, use o mesmo padrão de hash do Model; nunca grave senha em texto puro.

### Cadastrar AOE, coordenação e administrador

Com o MongoDB ativo e o ambiente virtual ativado, execute o comando abaixo na raiz do projeto:

```bash
python scripts/create_user.py --name "Nome da AOE" --email "aoe@escola.com" --profile AOE
```

O comando solicitará a senha duas vezes e armazenará somente o hash. Para os outros perfis:

```bash
python scripts/create_user.py --name "Coordenação" --email "coordenacao@escola.com" --profile COORDINATION
python scripts/create_user.py --name "Administrador" --email "admin@escola.com" --profile ADMIN
```

Perfis disponíveis:

- `AOE`: lançamento e consulta operacional das frequências.
- `COORDINATION`: dashboard, justificativas e acompanhamento gerencial.
- `ADMIN`: administração geral do sistema.

O e-mail é único. O cadastro não deve ser exposto como rota pública; ele deve ser executado por administrador ou durante a implantação.

A collection `justification_links` deve conter `token_hash`, `attendance_id`, `expires_at`, `active` e, após o uso, `used_at`. O token original deve ser enviado somente no e-mail e nunca armazenado no banco.

## Pendências para a entrega completa do prompt

Ainda precisam ser conectados ao projeto real:

1. seed completo das collections do SAA;
2. CRUD completo de alunos, turmas, matrículas, responsáveis e frequência;
3. gerador de token e integração de envio de e-mail;
4. notificações de e-mail e registro de tentativas;
5. autenticação e perfis AOE/coordenação/admin;
6. configuração do percentual mínimo por período;
7. testes de integração com MongoDB.

Esses pontos dependem das decisões de negócio que ainda não foram informadas e não devem ser inventados. Consulte `AUDITORIA_ENTREGA.md` para a matriz completa do que está implementado, parcial ou ausente.

## Fluxo de ausência (issues #42, #43, #45 e #49)

1. **Registrar ausência** (`/absences`): a AOE escolhe o aluno e a data. O sistema localiza a matrícula ativa na data, grava o registro `ABSENT` em `attendance_records` e abre a ocorrência em `justifications` com `status: PENDING` e `status_history`.
2. **Envio automático de e-mail**: logo após o registro, cada responsável vinculado (`student_guardians`, exceto quem tem `receives_absence_notifications: false`) recebe um e-mail com aluno, turma, data e um link de justificativa individual. Cada envio fica em `email_notifications` como `SENT` ou `FAILED` (com `failure_detail`). Uma falha de envio não desfaz o registro da ausência.
3. **Justificativa**: ao enviar o formulário, a ocorrência muda automaticamente para `RESPONDED` e o histórico recebe a nova entrada.
4. **Consulta de ocorrências** (`/occurrences`): lista com filtro por aluno, turma e status e contador de pendentes. O detalhe (`/occurrences/<id>`) mostra os dados, a justificativa, o histórico de status e as comunicações.

O disparo manual em `/email-dispatch` usa o mesmo envio e sempre manda para o e-mail cadastrado do responsável.

### Configuração do e-mail

| Variável | Descrição |
|---|---|
| `EMAIL_BACKEND` | `smtp` (padrão) ou `console` (só imprime o e-mail no terminal, para desenvolvimento) |
| `SMTP_HOST`, `SMTP_PORT` | Servidor SMTP (porta padrão 587) |
| `SMTP_USER`, `SMTP_PASSWORD` | Credenciais (para Gmail, use uma senha de app) |
| `SMTP_FROM` | Remetente; se ausente, usa `SMTP_USER` |
| `SMTP_STARTTLS` | `true` (padrão) ou `false` |

Sem `SMTP_HOST` configurado, os envios ficam registrados como `FAILED` com o motivo.

### Testes

`pytest` roda sem MongoDB instalado: o fluxo é testado com `mongomock` (`tests/test_absence_flow.py`).

## Dashboard gerencial (issues #46 e #48)

A visão geral (`/dashboard`) usa por padrão os **últimos 30 dias** e aceita filtros de data, turma e turno.

- **Indicadores:** alunos e responsáveis cadastrados (ativos), ausências no período, alunos faltantes, presença geral, justificativas recebidas, ocorrências pendentes e respondidas (com a taxa de resposta).
- **Gráficos:** ausências por turma, ocorrências pendentes × respondidas por turma, ausências por dia/mês/ano e presença média por turma. A tabela "Resumo por turma" mostra os mesmos números em texto.
- **Atualização automática:** a página consulta `GET /api/dashboard` a cada minuto (pausa quando a aba está oculta) e redesenha cards, gráficos e tabela sem recarregar.

Ausências sem justificativa registrada contam como pendentes. "Justificativas recebidas" são as ocorrências do período com status `RESPONDED`.

## Cadastros (issues #36 a #41)

| Tela | O que faz |
|---|---|
| `/students` e `/students/<id>` | Cadastro e edição de aluno: nome completo, matrícula (única), data de nascimento e turma. A turma cria ou ajusta a matrícula (`enrollments`) do período letivo. A ficha do aluno vincula responsáveis (já cadastrados ou novos), define o principal e quem recebe avisos, remove vínculos e mostra o histórico de matrículas. |
| `/guardians` e `/guardians/<id>` | Cadastro e edição de responsável: nome, e-mail (único) e telefone com DDD. Pode ser vinculado a um aluno já no cadastro. A ficha mostra os alunos vinculados. |
| `/classes` e `/classes/<id>` | Cadastro e edição de turma: nome, código (único no período), período letivo, série e turno. A ficha lista os alunos e permite associar novos; um aluno de outra turma do mesmo período é transferido. |
| `/users` | Somente perfil **ADMIN**: cadastro de usuários internos (AOE, Coordenação, Administrador) e busca por nome ou e-mail. O primeiro administrador continua sendo criado com `scripts/create_user.py`. |

Erros de validação aparecem no topo da página e os dados digitados são mantidos (exceto senhas). Ao mudar a turma de um aluno dentro do mesmo período, a matrícula é atualizada; as ausências já registradas passam a contar para a nova turma nos relatórios.

## Perfis e controle de acesso (issues #31 e #50)

Os perfis e permissões ficam em `services/access.py`. Cada rota declara a permissão exigida (`permission_required`) e as telas escondem menus, botões e formulários que o perfil não pode usar.

| Permissão | Administrador | Coordenador | AOE | Secretária | Responsável |
|---|:-:|:-:|:-:|:-:|:-:|
| Ver o painel de indicadores | ✓ | ✓ | ✓ | | |
| Registrar ausências | ✓ | ✓ | ✓ | | |
| Consultar ocorrências e justificativas | ✓ | ✓ | ✓ | | |
| Enviar comunicações por e-mail | ✓ | ✓ | ✓ | | |
| Consultar alunos, turmas e responsáveis | ✓ | ✓ | ✓ | ✓ | |
| Cadastrar e alterar alunos, turmas e responsáveis | ✓ | | ✓ | ✓ | |
| Cadastrar usuários e definir perfis | ✓ | | | | |
| Enviar justificativa pelo link do e-mail | | | | | ✓ |

- **Responsável** não tem login: acessa apenas o formulário de justificativa pelo link individual.
- O perfil é relido do banco a cada requisição: trocar o perfil ou desativar um usuário em `/users` vale imediatamente.
- O administrador não pode remover o próprio acesso, e o sistema sempre mantém pelo menos um administrador ativo.
- `/profiles` mostra a matriz de permissões e `/me` mostra o perfil do usuário logado.
- Após o login, cada perfil vai para a sua página inicial (Secretária vai para Alunos). O parâmetro `next` só aceita caminhos internos.

## Recuperação de senha (issue #32)

1. No login, **"Esqueceu a senha?"** leva a `/forgot-password`, onde o usuário informa o e-mail.
2. O sistema gera um token aleatório, guarda só o hash (`password_resets`) e envia por e-mail o link `/reset-password/<token>`. O link vale por **1 hora**, pode ser usado **uma vez**, e um novo pedido invalida o anterior.
3. Na página do link, o usuário define a nova senha (mínimo 8 caracteres, com confirmação). As sessões abertas com a senha antiga são encerradas.

Proteções: a resposta é sempre a mesma, exista ou não o e-mail (não revela quem tem cadastro); no máximo 3 pedidos por usuário por hora; usuários inativos não recebem link.

Defina `APP_BASE_URL` (ex.: `https://saa.escola.com.br`) em produção: os links de redefinição de senha e de justificativa usam esse endereço, em vez do host da requisição, que pode ser forjado.
