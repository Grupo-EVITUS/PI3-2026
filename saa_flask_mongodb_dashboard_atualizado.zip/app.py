from datetime import datetime, timezone
from functools import wraps
import hmac
import os
from flask import Flask, abort, flash, g, jsonify, redirect, render_template, request, session, url_for
from bson import ObjectId
from pymongo.errors import DuplicateKeyError
from config import APP_BASE_URL, SECRET_KEY
from controllers.absence_controller import notify_guardian, register_absence_and_notify
from services.email_sender import EmailSendError, send_email
from controllers.dashboard_controller import get_dashboard_data
from controllers.registry_controller import RELATIONSHIPS, SHIFTS, parse_new_password, parse_class_form, parse_guardian_form, parse_link_form, parse_student_form, parse_user_form
from controllers.aoe_crud_controller import COLLECTIONS, build_document, duplicate_error_message, validate_document
from models.saa_model import SAARepository
from services.access import GRANTS, LOGIN_PROFILES, PERMISSIONS, PROFILES, can, home_endpoint, profile_label

app = Flask(__name__, template_folder="views/templates", static_folder="views/static")
app.config["SECRET_KEY"] = SECRET_KEY


def repo():
    return SAARepository()


def json_safe(value):
    if isinstance(value, ObjectId):
        return str(value)
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, list):
        return [json_safe(item) for item in value]
    if isinstance(value, dict):
        return {key: json_safe(item) for key, item in value.items()}
    return value


@app.before_request
def load_current_user():
    """Recarrega o usuário a cada requisição: perfil alterado ou usuário desativado vale na hora."""
    g.user = None
    if "user_id" not in session:
        return
    r = repo()
    try:
        user = r.get_user(session["user_id"])
    except ValueError:
        user = None
    finally:
        r.close()
    # session_version muda quando a senha é redefinida: encerra as sessões abertas antes disso.
    if not user or not user.get("active") or user.get("profile") not in LOGIN_PROFILES or session.get("session_version", 0) != user.get("session_version", 0):
        session.clear()
        return
    g.user = user
    session["user_name"] = user.get("name", "Usuário")
    session["profile"] = user["profile"]


def current_profile():
    return g.user["profile"] if g.get("user") else None


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not g.get("user"):
            return redirect(url_for("aoe_login", next=request.full_path))
        return view(*args, **kwargs)
    return wrapped


def require(permission):
    if not can(current_profile(), permission):
        abort(403, description=f"Seu perfil ({profile_label(current_profile())}) não tem permissão para: {PERMISSIONS[permission].lower()}.")


def permission_required(permission, write=None):
    """Exige `permission`; se `write` for informado, ele é exigido em requisições que alteram dados."""
    def decorator(view):
        @wraps(view)
        @login_required
        def wrapped(*args, **kwargs):
            require(write if write and request.method not in ("GET", "HEAD") else permission)
            return view(*args, **kwargs)
        return wrapped
    return decorator


@app.errorhandler(403)
def forbidden(error):
    return render_template("forbidden.html", message=error.description, user_name=session.get("user_name")), 403


@app.context_processor
def labels():
    return {
        "SHIFT_LABELS": SHIFTS,
        "PROFILE_LABELS": {code: item["label"] for code, item in PROFILES.items()},
        "RELATIONSHIP_LABELS": RELATIONSHIPS,
        "can": lambda permission: can(current_profile(), permission),
    }


# Permissões da API genérica por recurso: (consulta, alteração).
API_PERMISSIONS = {
    "students": ("registry.view", "registry.edit"),
    "classes": ("registry.view", "registry.edit"),
    "guardians": ("registry.view", "registry.edit"),
    "enrollments": ("registry.view", "registry.edit"),
    "attendance": ("occurrences.view", "absences.register"),
    "notifications": ("communications.send", "communications.send"),
}


def check_api_permission(resource):
    view_permission, write_permission = API_PERMISSIONS[resource]
    require(view_permission if request.method == "GET" else write_permission)


def public_base_url():
    return APP_BASE_URL or request.url_root.rstrip("/")


def safe_next(target):
    # Só aceita caminhos internos, para o login não virar redirecionamento para outro site.
    if target and target.startswith("/") and not target.startswith("//") and "\\" not in target:
        return target
    return None


@app.get("/")
def index():
    if not g.get("user"):
        return redirect(url_for("aoe_login"))
    return redirect(url_for(home_endpoint(current_profile())))


@app.route("/login", methods=["GET", "POST"])
def aoe_login():
    if request.method == "GET":
        return render_template("aoe_login.html")
    email = request.form.get("email", "")
    password = request.form.get("password", "")
    r = repo()
    try:
        user = r.authenticate_user(email, password, allowed_profiles=LOGIN_PROFILES)
    finally:
        r.close()
    if not user:
        return render_template("aoe_login.html", error="E-mail ou senha inválidos."), 401
    session.clear()
    session["user_id"] = str(user["_id"])
    session["user_name"] = user.get("name", "Usuário")
    session["profile"] = user.get("profile")
    session["session_version"] = user.get("session_version", 0)
    return redirect(safe_next(request.form.get("next")) or url_for(home_endpoint(user["profile"])))


RESET_REQUEST_MESSAGE = "Se o e-mail estiver cadastrado, você receberá em instantes um link para criar uma nova senha. O link vale por 1 hora."


@app.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    if request.method == "GET":
        return render_template("forgot_password.html")
    email = request.form.get("email", "").strip()
    if not email:
        return render_template("forgot_password.html", error="Informe o e-mail de login."), 400
    r = repo()
    try:
        created = r.create_password_reset(email, LOGIN_PROFILES)
    finally:
        r.close()
    if created:
        user, token = created
        link = f"{public_base_url()}{url_for('reset_password', token=token)}"
        body = (
            f"Olá, {user.get('name', 'usuário')}.\n\n"
            "Recebemos um pedido para redefinir a sua senha no SAA. Para criar uma nova senha, acesse:\n\n"
            f"{link}\n\n"
            "O link vale por 1 hora e pode ser usado uma única vez. Se você não fez este pedido, ignore este e-mail: a sua senha atual continua valendo."
        )
        try:
            send_email(user["email_normalized"], "Redefinição de senha — SAA", body)
        except EmailSendError as exc:
            app.logger.error("Falha ao enviar e-mail de redefinição de senha: %s", exc)
    # Mesma resposta para e-mail existente ou não, para não revelar quem tem cadastro.
    return render_template("forgot_password.html", sent=True, message=RESET_REQUEST_MESSAGE)


@app.route("/reset-password/<token>", methods=["GET", "POST"])
def reset_password(token):
    r = repo()
    try:
        if not r.find_password_reset(token):
            return render_template("reset_password.html", invalid=True), 410
        if request.method == "GET":
            return render_template("reset_password.html")
        try:
            password = parse_new_password(request.form)
        except ValueError as exc:
            return render_template("reset_password.html", error=str(exc)), 400
        if not r.reset_password(token, password):
            return render_template("reset_password.html", invalid=True), 410
    finally:
        r.close()
    session.clear()
    flash("Senha redefinida. Entre com a nova senha.")
    return redirect(url_for("aoe_login"))


@app.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("aoe_login"))


@app.get("/dashboard")
@permission_required("dashboard.view")
def dashboard():
    r = repo()
    try:
        data = get_dashboard_data(request.args, r)
        classes = r.list_classes(request.args.get("period_id") or None)
        return render_template("dashboard.html", data=json_safe(data), classes=json_safe(classes), filters=request.args, user_name=session.get("user_name"))
    finally:
        r.close()


@app.get("/api/dashboard")
@permission_required("dashboard.view")
def dashboard_api():
    r = repo()
    try:
        return jsonify(json_safe(get_dashboard_data(request.args, r)))
    finally:
        r.close()


@app.route("/students", methods=["GET", "POST"])
@permission_required("registry.view", write="registry.edit")
def students():
    r = repo()
    try:
        error = None
        if request.method == "POST":
            try:
                student_id = r.create_student(parse_student_form(request.form))
                flash("Aluno cadastrado com sucesso.")
                return redirect(url_for("student_detail", student_id=student_id))
            except ValueError as exc:
                error = str(exc)
            except DuplicateKeyError:
                error = "Já existe um aluno com esta matrícula."
        return render_template("students.html", students=r.list_students_overview(), classes=r.list_classes(), form=request.form, error=error, user_name=session.get("user_name")), 400 if error else 200
    finally:
        r.close()


@app.route("/students/<student_id>", methods=["GET", "POST"])
@permission_required("registry.view", write="registry.edit")
def student_detail(student_id):
    r = repo()
    try:
        error = None
        if request.method == "POST":
            try:
                r.update_student(student_id, parse_student_form(request.form))
                flash("Dados do aluno atualizados.")
                return redirect(url_for("student_detail", student_id=student_id))
            except ValueError as exc:
                error = str(exc)
            except DuplicateKeyError:
                error = "Já existe outro aluno com esta matrícula."
        try:
            student = r.student_detail(student_id)
        except ValueError:
            abort(404, description="Aluno não encontrado.")
        linked = {link["guardian_id"] for link in student["guardians"]}
        available = [g for g in r.list_guardians_overview() if g["_id"] not in linked]
        return render_template("student_detail.html", student=student, classes=r.list_classes(), guardians=available, relationships=RELATIONSHIPS, form=request.form if error else None, error=error, user_name=session.get("user_name")), 400 if error else 200
    finally:
        r.close()


@app.post("/students/<student_id>/guardians")
@permission_required("registry.edit")
def student_link_guardian(student_id):
    r = repo()
    try:
        try:
            link = parse_link_form(request.form)
            guardian_id = request.form.get("guardian_id", "").strip()
            if guardian_id:
                r.link_guardian(student_id, guardian_id, link)
            else:
                r.link_guardian(student_id, r.create_guardian(parse_guardian_form(request.form)), link)
            flash("Responsável vinculado ao aluno.")
        except ValueError as exc:
            flash(str(exc), "error")
        except DuplicateKeyError:
            flash("Já existe um responsável com este e-mail. Selecione-o na lista de responsáveis cadastrados.", "error")
        return redirect(url_for("student_detail", student_id=student_id) + "#responsaveis")
    finally:
        r.close()


@app.post("/students/<student_id>/guardians/<guardian_id>/remove")
@permission_required("registry.edit")
def student_unlink_guardian(student_id, guardian_id):
    r = repo()
    try:
        try:
            removed = r.unlink_guardian(student_id, guardian_id)
        except ValueError:
            removed = False
        flash("Vínculo removido." if removed else "Vínculo não encontrado.", None if removed else "error")
        return redirect(url_for("student_detail", student_id=student_id) + "#responsaveis")
    finally:
        r.close()


@app.route("/guardians", methods=["GET", "POST"])
@permission_required("registry.view", write="registry.edit")
def guardians():
    r = repo()
    try:
        error = None
        if request.method == "POST":
            try:
                data = parse_guardian_form(request.form)
                student_id = request.form.get("student_id", "").strip()
                link = parse_link_form(request.form) if student_id else None
                if student_id:
                    r._active_student(student_id)
                guardian_id = r.create_guardian(data)
                if student_id:
                    r.link_guardian(student_id, guardian_id, link)
                flash("Responsável cadastrado com sucesso.")
                return redirect(url_for("guardian_detail", guardian_id=guardian_id))
            except ValueError as exc:
                error = str(exc)
            except DuplicateKeyError:
                error = "Já existe um responsável com este e-mail."
        return render_template("guardians.html", guardians=r.list_guardians_overview(), students=r.list_students(), relationships=RELATIONSHIPS, form=request.form, error=error, user_name=session.get("user_name")), 400 if error else 200
    finally:
        r.close()


@app.route("/guardians/<guardian_id>", methods=["GET", "POST"])
@permission_required("registry.view", write="registry.edit")
def guardian_detail(guardian_id):
    r = repo()
    try:
        error = None
        if request.method == "POST":
            try:
                r.update_guardian(guardian_id, parse_guardian_form(request.form))
                flash("Dados do responsável atualizados.")
                return redirect(url_for("guardian_detail", guardian_id=guardian_id))
            except ValueError as exc:
                error = str(exc)
            except DuplicateKeyError:
                error = "Já existe outro responsável com este e-mail."
        try:
            guardian = r.guardian_detail(guardian_id)
        except ValueError:
            guardian = None
        if not guardian:
            abort(404, description="Responsável não encontrado.")
        return render_template("guardian_detail.html", guardian=guardian, relationships=RELATIONSHIPS, form=request.form if error else None, error=error, user_name=session.get("user_name")), 400 if error else 200
    finally:
        r.close()


@app.route("/classes", methods=["GET", "POST"])
@permission_required("registry.view", write="registry.edit")
def classes():
    r = repo()
    try:
        error = None
        if request.method == "POST":
            try:
                class_id = r.create_class(parse_class_form(request.form))
                flash("Turma cadastrada com sucesso.")
                return redirect(url_for("class_detail", class_id=class_id))
            except ValueError as exc:
                error = str(exc)
            except DuplicateKeyError:
                error = "Já existe uma turma com este código neste período letivo."
        return render_template("classes.html", classes=r.list_classes_overview(), shifts=SHIFTS, form=request.form, current_year=datetime.now(timezone.utc).year, error=error, user_name=session.get("user_name")), 400 if error else 200
    finally:
        r.close()


@app.route("/classes/<class_id>", methods=["GET", "POST"])
@permission_required("registry.view", write="registry.edit")
def class_detail(class_id):
    r = repo()
    try:
        error = None
        if request.method == "POST":
            try:
                r.update_class(class_id, parse_class_form(request.form))
                flash("Dados da turma atualizados.")
                return redirect(url_for("class_detail", class_id=class_id))
            except ValueError as exc:
                error = str(exc)
            except DuplicateKeyError:
                error = "Já existe uma turma com este código neste período letivo."
        try:
            school_class = r.class_detail(class_id)
        except ValueError:
            school_class = None
        if not school_class:
            abort(404, description="Turma não encontrada.")
        enrolled = {s["_id"] for s in school_class["students"]}
        candidates = [s for s in r.list_students_overview() if s["_id"] not in enrolled]
        return render_template("class_detail.html", school_class=school_class, candidates=candidates, shifts=SHIFTS, form=request.form if error else None, error=error, user_name=session.get("user_name")), 400 if error else 200
    finally:
        r.close()


@app.post("/classes/<class_id>/students")
@permission_required("registry.edit")
def class_add_student(class_id):
    r = repo()
    try:
        try:
            r.add_student_to_class(class_id, request.form.get("student_id", "").strip())
            flash("Aluno associado à turma.")
        except ValueError as exc:
            flash(str(exc), "error")
        return redirect(url_for("class_detail", class_id=class_id))
    finally:
        r.close()


@app.route("/users", methods=["GET", "POST"])
@permission_required("users.manage")
def users():
    r = repo()
    try:
        error = None
        if request.method == "POST":
            try:
                data = parse_user_form(request.form)
                r.create_internal_user(data["name"], data["email"], data["password"], data["profile"])
                flash(f"Usuário {data['email'].lower()} cadastrado com sucesso.")
                return redirect(url_for("users"))
            except ValueError as exc:
                error = str(exc)
            except DuplicateKeyError:
                error = "Já existe um usuário com este e-mail."
        search = request.args.get("q", "").strip()
        form = {key: value for key, value in request.form.items() if not key.startswith("password")}
        return render_template("users.html", users=r.list_users(search), search=search, login_profiles=LOGIN_PROFILES, form=form, error=error, user_name=session.get("user_name")), 400 if error else 200
    finally:
        r.close()


@app.post("/users/<user_id>/access")
@permission_required("users.manage")
def user_access(user_id):
    profile = request.form.get("profile", "").strip()
    active = request.form.get("active") == "on"
    r = repo()
    try:
        try:
            if profile not in LOGIN_PROFILES:
                raise ValueError("Perfil inválido para acesso interno.")
            if user_id == str(g.user["_id"]) and (profile != "ADMIN" or not active):
                raise ValueError("Você não pode remover o seu próprio acesso de administrador.")
            r.update_user_access(user_id, profile, active)
            flash("Perfil e situação do usuário atualizados.")
        except ValueError as exc:
            flash(str(exc), "error")
        return redirect(url_for("users"))
    finally:
        r.close()


@app.get("/profiles")
@login_required
def profiles():
    return render_template("profiles.html", profiles=PROFILES, permissions=PERMISSIONS, grants=GRANTS, user_name=session.get("user_name"))


@app.get("/me")
@login_required
def my_profile():
    profile = PROFILES[current_profile()]
    granted = [label for code, label in PERMISSIONS.items() if can(current_profile(), code)]
    return render_template("my_profile.html", user=g.user, profile=profile, granted=granted, user_name=session.get("user_name"))


@app.get("/api/notification-context")
@permission_required("communications.send")
def notification_context_api():
    student_id = request.args.get("student_id", "").strip()
    attendance_id = request.args.get("attendance_id", "").strip() or None
    if not student_id:
        abort(400, description="student_id é obrigatório.")
    r = repo()
    try:
        context = r.notification_context(student_id, attendance_id)
        if not context:
            abort(404, description="Aluno não encontrado.")
        return jsonify(json_safe(context))
    except ValueError as exc:
        abort(400, description=str(exc))
    finally:
        r.close()


@app.route("/email-dispatch", methods=["GET", "POST"])
@permission_required("communications.send")
def email_dispatch():
    r = repo()
    try:
        message = None
        if request.method == "POST":
            payload = request.form
            required = ("student_id", "attendance_id", "guardian_id", "recipient_email", "subject", "body")
            if any(not payload.get(field, "").strip() for field in required):
                abort(400, description="Selecione aluno, ocorrência, responsável, e-mail, assunto e mensagem.")
            try:
                context = r.notification_context(payload["student_id"].strip(), payload["attendance_id"].strip())
            except ValueError as exc:
                abort(400, description=str(exc))
            guardian = next((item for item in (context or {}).get("guardians", []) if str(item["guardian_id"]) == payload["guardian_id"].strip()), None)
            if not guardian:
                abort(400, description="O responsável não está vinculado ao aluno selecionado.")
            if not context["absences"]:
                abort(400, description="A ocorrência selecionada não pertence ao aluno ou não é uma ausência.")
            # O e-mail usado é sempre o cadastrado do responsável, não o enviado pelo formulário.
            notification = notify_guardian(r, public_base_url(), context["student"]["_id"], context["absences"][0]["_id"], guardian, r.object_id(session["user_id"]), payload["subject"], payload["body"])
            if notification["status"] == "SENT":
                message = f"E-mail enviado para {notification['recipient_email']}."
            else:
                message = f"Não foi possível enviar o e-mail: {notification['failure_detail']} A comunicação ficou registrada como falha."
        notifications = r.list_collection("email_notifications", {}, 30)
        return render_template("email_dispatch.html", notifications=notifications, students=r.list_students(), user_name=session.get("user_name"), message=message)
    finally:
        r.close()


@app.post("/api/webhooks/email")
def email_webhook():
    """Recebe eventos SENT/DELIVERED/OPENED/FAILED do provedor configurado."""
    configured_secret = os.getenv("EMAIL_WEBHOOK_SECRET")
    received_secret = request.headers.get("X-Email-Webhook-Secret", "")
    if not configured_secret or not hmac.compare_digest(received_secret, configured_secret):
        abort(401, description="Webhook não autorizado.")
    payload = request.get_json(silent=True) or {}
    notification_id = payload.get("notification_id")
    event = payload.get("event")
    if not notification_id or event not in {"SENT", "DELIVERED", "OPENED", "FAILED"}:
        abort(400, description="notification_id e event válido são obrigatórios.")
    r = repo()
    try:
        identifier = r.object_id(notification_id)
        now = datetime.now(timezone.utc)
        changes = {"status": event, "last_event_at": now}
        if event == "OPENED":
            changes["opened_at"] = now
            changes["open_count"] = 1
        if event == "FAILED":
            changes["failure_detail"] = payload.get("detail", "Falha informada pelo provedor")
        result = r.db.email_notifications.update_one({"_id": identifier}, {"$set": changes})
        if result.matched_count != 1:
            abort(404, description="Notificação não encontrada.")
        return jsonify({"success": True, "notification_id": notification_id, "status": event})
    except ValueError as exc:
        abort(400, description=str(exc))
    finally:
        r.close()


@app.post("/attendance")
@permission_required("absences.register")
def create_attendance():
    payload = request.form or request.get_json(silent=True) or {}
    required = ("enrollment_id", "date", "status")
    if any(not payload.get(key) for key in required):
        abort(400, description="enrollment_id, date e status são obrigatórios.")
    if payload["status"] not in {"PRESENT", "ABSENT", "NOT_REGISTERED", "EXCUSED"}:
        abort(400, description="Situação de frequência inválida.")
    r = repo()
    try:
        r.create_attendance({"enrollment_id": r.object_id(payload["enrollment_id"]), "date": datetime.strptime(payload["date"], "%Y-%m-%d").replace(tzinfo=timezone.utc), "status": payload["status"], "registered_by": r.object_id(session["user_id"])})
    except Exception as exc:
        if exc.__class__.__name__ == "DuplicateKeyError":
            abort(409, description="Já existe frequência para esta matrícula e data.")
        raise
    finally:
        r.close()
    return redirect(url_for("dashboard"))


@app.route("/absences", methods=["GET", "POST"])
@permission_required("absences.register")
def absences():
    r = repo()
    try:
        result, error, status_code = None, None, 200
        if request.method == "POST":
            student_id = request.form.get("student_id", "").strip()
            date_text = request.form.get("date", "").strip()
            try:
                if not student_id or not date_text:
                    raise ValueError("Selecione o aluno e a data da ausência.")
                try:
                    date = datetime.strptime(date_text, "%Y-%m-%d").replace(tzinfo=timezone.utc)
                except ValueError:
                    raise ValueError("Data inválida.")
                result = register_absence_and_notify(r, public_base_url(), student_id, date, r.object_id(session["user_id"]), request.form.get("notes", "").strip())
            except ValueError as exc:
                error, status_code = str(exc), 400
            except DuplicateKeyError:
                error, status_code = "Já existe frequência registrada para este aluno nesta data.", 409
        return render_template("absences.html", students=r.list_students(), recent=r.list_occurrences(limit=10), result=result, error=error, form=request.form, today=datetime.now(timezone.utc).strftime("%Y-%m-%d"), user_name=session.get("user_name")), status_code
    finally:
        r.close()


@app.get("/occurrences")
@permission_required("occurrences.view")
def occurrences():
    r = repo()
    try:
        filters = {key: request.args.get(key, "").strip() or None for key in ("student_id", "class_id", "status")}
        try:
            items = r.list_occurrences(**filters)
        except ValueError as exc:
            abort(400, description=str(exc))
        pending = sum(1 for item in items if item["occurrence_status"] == "PENDING")
        return render_template("occurrences.html", occurrences=items, pending=pending, students=r.list_students(), classes=r.list_classes(), filters=request.args, user_name=session.get("user_name"))
    finally:
        r.close()


@app.get("/occurrences/<attendance_id>")
@permission_required("occurrences.view")
def occurrence_detail(attendance_id):
    r = repo()
    try:
        try:
            occurrence = r.occurrence_detail(attendance_id)
        except ValueError as exc:
            abort(400, description=str(exc))
        if not occurrence:
            abort(404, description="Ocorrência não encontrada.")
        return render_template("occurrence_detail.html", occurrence=occurrence, user_name=session.get("user_name"))
    finally:
        r.close()


@app.get("/justify/<token>")
def public_justification_form(token):
    r = repo()
    try:
        link = r.find_justification_link(token)
        if not link:
            abort(410, description="Este link é inválido, expirou ou já foi utilizado.")
        return render_template("justification.html", token=token)
    finally:
        r.close()


@app.post("/justify/<token>")
def submit_public_justification(token):
    reason = request.form.get("reason", "").strip()
    explanation = request.form.get("explanation", "").strip()
    if not reason or (reason == "OTHER" and not explanation):
        abort(400, description="Informe o motivo e a explicação quando selecionar Outro.")
    r = repo()
    try:
        success, message = r.submit_public_justification(token, reason, explanation)
    finally:
        r.close()
    if not success:
        abort(410, description=message)
    return render_template("justification_success.html")


@app.get("/api/<resource>")
@login_required
def crud_list(resource):
    if resource not in COLLECTIONS:
        abort(404, description="Recurso não encontrado.")
    check_api_permission(resource)
    r = repo()
    try:
        query = {"active": True} if resource != "attendance" else {}
        return jsonify([json_safe(item) for item in r.list_collection(COLLECTIONS[resource], query)])
    finally:
        r.close()


@app.post("/api/<resource>")
@login_required
def crud_create(resource):
    if resource not in COLLECTIONS:
        abort(404, description="Recurso não encontrado.")
    check_api_permission(resource)
    payload = request.get_json(silent=True) or request.form.to_dict()
    r = repo()
    try:
        document = build_document(resource, payload, session["user_id"])
        validate_document(r, resource, document)
        identifier = r.insert_document(COLLECTIONS[resource], document)
        return jsonify({"id": str(identifier), "message": "Registro criado com sucesso."}), 201
    except ValueError as exc:
        abort(400, description=str(exc))
    except DuplicateKeyError:
        abort(409, description=duplicate_error_message(resource))
    finally:
        r.close()


@app.get("/api/<resource>/<identifier>")
@login_required
def crud_get(resource, identifier):
    if resource not in COLLECTIONS:
        abort(404, description="Recurso não encontrado.")
    check_api_permission(resource)
    r = repo()
    try:
        item = r.find_one(COLLECTIONS[resource], identifier)
        if not item:
            abort(404, description="Registro não encontrado.")
        return jsonify(json_safe(item))
    except ValueError as exc:
        abort(400, description=str(exc))
    finally:
        r.close()


@app.patch("/api/<resource>/<identifier>")
@login_required
def crud_update(resource, identifier):
    if resource not in COLLECTIONS:
        abort(404, description="Recurso não encontrado.")
    check_api_permission(resource)
    changes = request.get_json(silent=True) or request.form.to_dict()
    allowed = {"name", "school_id", "code", "academic_period_id", "grade", "shift", "email", "phone", "active", "start_date", "end_date", "status"}
    changes = {key: value for key, value in changes.items() if key in allowed}
    if "email" in changes:
        changes["email_normalized"] = changes["email"].strip().lower()
    if "start_date" in changes:
        changes["start_date"] = __import__("controllers.aoe_crud_controller", fromlist=["utc_date"]).utc_date(changes["start_date"])
    if "end_date" in changes:
        changes["end_date"] = __import__("controllers.aoe_crud_controller", fromlist=["utc_date"]).utc_date(changes["end_date"])
    r = repo()
    try:
        if resource == "attendance" and "status" in changes and changes["status"] not in {"PRESENT", "ABSENT", "NOT_REGISTERED", "EXCUSED"}:
            abort(400, description="Status de frequência inválido.")
        if not r.update_document(COLLECTIONS[resource], identifier, changes):
            abort(404, description="Registro não encontrado.")
        return jsonify({"message": "Registro atualizado com sucesso."})
    except ValueError as exc:
        abort(400, description=str(exc))
    except DuplicateKeyError:
        abort(409, description=duplicate_error_message(resource))
    finally:
        r.close()


@app.delete("/api/<resource>/<identifier>")
@login_required
def crud_delete(resource, identifier):
    if resource not in COLLECTIONS:
        abort(404, description="Recurso não encontrado.")
    check_api_permission(resource)
    if resource in {"attendance", "enrollments"}:
        abort(409, description="Registros históricos de frequência e matrícula não devem ser apagados; arquive-os ou encerre sua vigência.")
    r = repo()
    try:
        if not r.archive_document(COLLECTIONS[resource], identifier):
            abort(404, description="Registro não encontrado.")
        return jsonify({"message": "Registro arquivado com sucesso."})
    except ValueError as exc:
        abort(400, description=str(exc))
    finally:
        r.close()


if __name__ == "__main__":
    SAARepository().ensure_indexes()
    app.run(host="0.0.0.0", port=5000, debug=True)
