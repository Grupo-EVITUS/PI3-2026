import os
from dotenv import load_dotenv

load_dotenv()

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
MONGO_DB = os.getenv("MONGO_DB", "saa")
SECRET_KEY = os.getenv("SECRET_KEY", "dev-change-this-key")

# Premissa inicial: frequência diária, um registro por matrícula e data.
ATTENDANCE_GRANULARITY = "daily"
