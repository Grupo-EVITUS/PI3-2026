import os
from dotenv import load_dotenv

load_dotenv()

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
MONGO_DB = os.getenv("MONGO_DB", "saa")
SECRET_KEY = os.getenv("SECRET_KEY", "dev-change-this-key")
# Endereço público do sistema, usado nos links enviados por e-mail (ex.: https://saa.escola.com.br).
# Em produção, defina sempre: sem ele o link usa o host da requisição.
APP_BASE_URL = os.getenv("APP_BASE_URL", "").rstrip("/")

# Premissa inicial: frequência diária, um registro por matrícula e data.
ATTENDANCE_GRANULARITY = "daily"
