from datetime import datetime, timedelta, timezone
from services.email_sender import EmailSendError, send_email

LINK_VALIDITY_DAYS = 30
DEFAULT_SUBJECT = "Comunicado de ausência escolar"


def default_body(guardian_name, student_name, class_name, date):
    turma = f" ({class_name})" if class_name else ""
    return (
        f"Olá, {guardian_name}.\n\n"
        f"Informamos que foi registrada uma ausência de {student_name}{turma} em {date.strftime('%d/%m/%Y')}.\n\n"
        f"Pedimos que informe o motivo pelo link abaixo. Ele é válido por {LINK_VALIDITY_DAYS} dias e pode ser usado uma única vez."
    )


def notify_guardian(repository, url_root, student_id, attendance_id, guardian, created_by, subject, body):
    """Gera o link de justificativa, registra a notificação e tenta enviá-la.

    Falhas de envio não interrompem o fluxo: a notificação fica como FAILED
    com o motivo em failure_detail. Retorna o documento da notificação.
    """
    token = repository.create_justification_link(attendance_id, guardian["guardian_id"], datetime.now(timezone.utc) + timedelta(days=LINK_VALIDITY_DAYS))
    justification_url = f"{url_root.rstrip('/')}/justify/{token}"
    full_body = body.strip() + f"\n\nAcesse o formulário de justificativa: {justification_url}"
    notification = {
        "student_id": student_id,
        "attendance_id": attendance_id,
        "guardian_id": guardian["guardian_id"],
        "recipient_email": guardian["email"].strip().lower(),
        "subject": subject.strip(),
        "body": full_body,
        "justification_url": justification_url,
        "status": "PENDING",
        "open_count": 0,
        "created_by": created_by,
    }
    notification["_id"] = repository.insert_document("email_notifications", notification)
    now = datetime.now(timezone.utc)
    try:
        send_email(notification["recipient_email"], notification["subject"], full_body)
        changes = {"status": "SENT", "attempted_at": now, "last_event_at": now}
    except EmailSendError as exc:
        changes = {"status": "FAILED", "attempted_at": now, "last_event_at": now, "failure_detail": str(exc)}
    repository.db.email_notifications.update_one({"_id": notification["_id"]}, {"$set": changes})
    notification.update(changes)
    return notification


def register_absence_and_notify(repository, url_root, student_id, date, user_id, notes=""):
    """Fluxo completo: grava a ausência, abre a ocorrência PENDING e avisa os responsáveis."""
    absence = repository.register_absence(student_id, date, user_id, notes)
    student = absence["student"]
    notifications = []
    for guardian in repository.student_guardians(student["_id"], only_notifiable=True):
        body = default_body(guardian.get("name") or "responsável", student["name"], absence["class_name"], date)
        notifications.append(notify_guardian(repository, url_root, student["_id"], absence["attendance_id"], guardian, user_id, DEFAULT_SUBJECT, body))
    absence["notifications"] = notifications
    return absence
