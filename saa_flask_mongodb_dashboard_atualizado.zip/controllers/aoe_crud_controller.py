from datetime import datetime, timezone
from bson import ObjectId
from pymongo.errors import DuplicateKeyError

COLLECTIONS = {
    "students": "students",
    "classes": "classes",
    "guardians": "guardians",
    "enrollments": "enrollments",
    "attendance": "attendance_records",
    "notifications": "email_notifications",
}


def utc_date(value):
    if isinstance(value, datetime):
        return value
        return datetime.strptime(value, "%Y-%m-%d").replace(tzinfo=timezone.utc)


def object_id(value, field):
    try:
        return ObjectId(value)
    except Exception as exc:
        raise ValueError(f"{field} inválido.") from exc


def build_document(resource, payload, user_id):
    payload = dict(payload)
    if resource == "students":
        document = {"name": payload.get("name", "").strip(), "school_id": payload.get("school_id"), "active": payload.get("active", True)}
    elif resource == "classes":
        document = {"name": payload.get("name", "").strip(), "code": payload.get("code"), "academic_period_id": payload.get("academic_period_id"), "grade": payload.get("grade"), "shift": payload.get("shift"), "active": payload.get("active", True)}
    elif resource == "guardians":
        document = {"name": payload.get("name", "").strip(), "email": payload.get("email", "").strip(), "phone": payload.get("phone"), "active": payload.get("active", True)}
    elif resource == "enrollments":
        document = {"student_id": object_id(payload.get("student_id"), "student_id"), "class_id": object_id(payload.get("class_id"), "class_id"), "academic_period_id": payload.get("academic_period_id"), "start_date": utc_date(payload["start_date"]) if payload.get("start_date") else None, "end_date": utc_date(payload["end_date"]) if payload.get("end_date") else None, "active": payload.get("active", True)}
    elif resource == "attendance":
        document = {"enrollment_id": object_id(payload.get("enrollment_id"), "enrollment_id"), "date": utc_date(payload["date"]) if payload.get("date") else None, "status": payload.get("status"), "registered_by": object_id(user_id, "registered_by") if len(str(user_id)) == 24 else user_id}
    else:
        raise ValueError("Recurso CRUD não suportado.")
    return document


def validate_document(repository, resource, document):
    validators = {
        "students": repository.validate_student,
        "classes": repository.validate_class,
        "guardians": repository.validate_guardian,
        "enrollments": repository.validate_enrollment,
        "attendance": repository.validate_attendance,
    }
    validators[resource](document)


def duplicate_error_message(resource):
    if resource == "attendance":
        return "Já existe frequência para esta matrícula e data."
    if resource == "enrollments":
        return "Já existe matrícula do aluno neste período letivo."
    return "Já existe um registro com os mesmos dados únicos."
