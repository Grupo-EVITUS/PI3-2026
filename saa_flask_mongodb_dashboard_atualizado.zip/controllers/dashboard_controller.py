from datetime import datetime, timezone
from flask import abort
from models.saa_model import SAARepository


def parse_date(value, default):
    if not value:
        return default
    try:
        return datetime.strptime(value, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    except ValueError:
        abort(400, description="Data inválida. Use o formato AAAA-MM-DD.")


def get_dashboard_data(args, repository=None):
    own_repo = repository is None
    repo = repository or SAARepository()
    try:
        now = datetime.now(timezone.utc)
        start = parse_date(args.get("start"), now.replace(hour=0, minute=0, second=0, microsecond=0))
        end = parse_date(args.get("end"), now)
        if start > end:
            abort(400, description="A data inicial não pode ser posterior à data final.")
        return repo.dashboard(start, end, class_id=args.get("class_id") or None, period_id=args.get("period_id") or None, shift=args.get("shift") or None)
    finally:
        if own_repo:
            repo.close()
