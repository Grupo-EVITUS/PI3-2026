"""Validação dos formulários de cadastro. Cada função devolve um dicionário limpo ou lança ValueError."""
from datetime import datetime, timezone
import re

from services.access import LOGIN_PROFILES

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
SHIFTS = {"MORNING": "Manhã", "AFTERNOON": "Tarde", "NIGHT": "Noite"}
RELATIONSHIPS = {"MAE": "Mãe", "PAI": "Pai", "AVO": "Avó/Avô", "TIO": "Tia/Tio", "RESPONSAVEL_LEGAL": "Responsável legal", "OUTRO": "Outro"}


def text(form, field, label, required=True, max_length=120):
    value = (form.get(field) or "").strip()
    if required and not value:
        raise ValueError(f"{label} é obrigatório.")
    if len(value) > max_length:
        raise ValueError(f"{label} deve ter no máximo {max_length} caracteres.")
    return value


def parse_birth_date(value):
    try:
        date = datetime.strptime((value or "").strip(), "%Y-%m-%d").replace(tzinfo=timezone.utc)
    except ValueError:
        raise ValueError("Data de nascimento é obrigatória e deve ser uma data válida.")
    now = datetime.now(timezone.utc)
    if date > now:
        raise ValueError("A data de nascimento não pode estar no futuro.")
    if date.year < now.year - 100:
        raise ValueError("Data de nascimento inválida.")
    return date


def parse_student_form(form):
    name = text(form, "name", "Nome do aluno")
    if len(name.split()) < 2:
        raise ValueError("Informe o nome completo do aluno.")
    return {
        "name": name,
        "school_id": text(form, "school_id", "Matrícula", max_length=30),
        "birth_date": parse_birth_date(form.get("birth_date")),
        "class_id": text(form, "class_id", "Turma", max_length=24),
    }


def normalize_phone(value):
    digits = re.sub(r"\D", "", value or "")
    if len(digits) not in (10, 11):
        raise ValueError("Telefone deve ter DDD e 8 ou 9 dígitos, por exemplo (11) 98765-4321.")
    return f"({digits[:2]}) {digits[2:-4]}-{digits[-4:]}"


def parse_email(form, field="email"):
    email = text(form, field, "E-mail")
    if not EMAIL_RE.match(email):
        raise ValueError("Informe um e-mail válido.")
    return email


def parse_guardian_form(form):
    return {
        "name": text(form, "name", "Nome do responsável"),
        "email": parse_email(form),
        "phone": normalize_phone(form.get("phone")),
    }


def parse_link_form(form):
    relationship = (form.get("relationship") or "").strip()
    if relationship not in RELATIONSHIPS:
        raise ValueError("Selecione o parentesco.")
    return {
        "relationship": relationship,
        "is_primary": form.get("is_primary") == "on",
        "receives_absence_notifications": form.get("receives_absence_notifications") == "on",
    }


def parse_class_form(form):
    shift = (form.get("shift") or "").strip()
    if shift not in SHIFTS:
        raise ValueError("Selecione o turno.")
    period = text(form, "academic_period_id", "Período letivo", max_length=20)
    if not re.fullmatch(r"\d{4}(-\d)?", period):
        raise ValueError("Período letivo deve ser o ano, como 2026, ou ano-semestre, como 2026-1.")
    return {
        "name": text(form, "name", "Nome da turma", max_length=40),
        "code": text(form, "code", "Código da turma", max_length=20).upper(),
        "academic_period_id": period,
        "grade": text(form, "grade", "Série/ano", required=False, max_length=30),
        "shift": shift,
    }


def parse_user_form(form):
    profile = (form.get("profile") or "").strip()
    if profile not in LOGIN_PROFILES:
        raise ValueError("Selecione o perfil.")
    return {"name": text(form, "name", "Nome"), "email": parse_email(form), "password": parse_new_password(form), "profile": profile}


def parse_new_password(form):
    password = form.get("password") or ""
    if len(password) < 8:
        raise ValueError("A senha deve possuir pelo menos 8 caracteres.")
    if password != (form.get("password_confirmation") or ""):
        raise ValueError("As senhas não coincidem.")
    return password
