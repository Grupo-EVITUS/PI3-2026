from datetime import datetime, timedelta, timezone
import hashlib
import re
import secrets
from pymongo import ASCENDING, DESCENDING, MongoClient
from pymongo.errors import DuplicateKeyError
from werkzeug.security import check_password_hash, generate_password_hash
from config import MONGO_DB, MONGO_URI
from services.access import LOGIN_PROFILES
from bson import ObjectId


def utcnow():
    return datetime.now(timezone.utc)


class SAARepository:
    def __init__(self, uri=MONGO_URI, database=MONGO_DB):
        self.client = MongoClient(uri, serverSelectionTimeoutMS=3000)
        self.db = self.client[database]

    def close(self):
        self.client.close()

    @staticmethod
    def object_id(value):
        try:
            return ObjectId(value)
        except Exception:
            raise ValueError("Identificador MongoDB inválido.")

    def find_one(self, collection, identifier):
        return self.db[collection].find_one({"_id": self.object_id(identifier)})

    def list_collection(self, collection, query=None, limit=100):
        return list(self.db[collection].find(query or {}).sort("created_at", DESCENDING).limit(limit))

    def insert_document(self, collection, document):
        now = utcnow()
        document.setdefault("active", True)
        document.setdefault("created_at", now)
        document.setdefault("updated_at", now)
        return self.db[collection].insert_one(document).inserted_id

    def update_document(self, collection, identifier, changes):
        changes["updated_at"] = utcnow()
        result = self.db[collection].update_one({"_id": self.object_id(identifier)}, {"$set": changes})
        return result.matched_count == 1

    def archive_document(self, collection, identifier):
        return self.update_document(collection, identifier, {"active": False, "archived_at": utcnow()})

    def validate_student(self, document):
        if not document.get("name", "").strip():
            raise ValueError("Nome do aluno é obrigatório.")

    def validate_class(self, document):
        if not document.get("name", "").strip() or not document.get("academic_period_id"):
            raise ValueError("Nome da turma e período letivo são obrigatórios.")

    def validate_guardian(self, document):
        if not document.get("name", "").strip() or "@" not in document.get("email", ""):
            raise ValueError("Nome e e-mail válido do responsável são obrigatórios.")
        document["email_normalized"] = document["email"].strip().lower()

    def validate_enrollment(self, document):
        for field in ("student_id", "class_id", "academic_period_id"):
            if not document.get(field):
                raise ValueError(f"{field} é obrigatório.")

    def validate_attendance(self, document):
        if document.get("status") not in {"PRESENT", "ABSENT", "NOT_REGISTERED", "EXCUSED"}:
            raise ValueError("Status de frequência inválido.")
        if not document.get("enrollment_id") or not document.get("date"):
            raise ValueError("Matrícula e data são obrigatórias.")

    def ensure_indexes(self):
        self.db.students.create_index([("school_id", ASCENDING)], unique=True, sparse=True)
        self.db.classes.create_index([("academic_period_id", ASCENDING), ("code", ASCENDING)], unique=True)
        self.db.enrollments.create_index([("student_id", ASCENDING), ("academic_period_id", ASCENDING)], unique=True)
        self.db.enrollments.create_index([("class_id", ASCENDING), ("academic_period_id", ASCENDING)])
        self.db.attendance_records.create_index(
            [("enrollment_id", ASCENDING), ("date", ASCENDING)], unique=True
        )
        self.db.attendance_records.create_index([("date", ASCENDING), ("status", ASCENDING)])
        self.db.justification_reasons.create_index("code", unique=True)
        self.db.justifications.create_index([("attendance_id", ASCENDING)], unique=True)
        self.db.justifications.create_index([("status", ASCENDING), ("submitted_at", DESCENDING)])
        self.db.guardians.create_index("email_normalized", unique=True, sparse=True)
        self.db.student_guardians.create_index([("student_id", ASCENDING), ("guardian_id", ASCENDING)], unique=True)
        self.db.email_notifications.create_index([("attendance_id", ASCENDING), ("guardian_id", ASCENDING)])
        self.db.email_notifications.create_index([("status", ASCENDING), ("attempted_at", DESCENDING)])
        self.db.users.create_index("email_normalized", unique=True)
        self.db.justification_links.create_index("token_hash", unique=True)
        self.db.password_resets.create_index("token_hash", unique=True)
        self.db.password_resets.create_index([("user_id", ASCENDING), ("created_at", DESCENDING)])
        self.db.justification_links.create_index([("expires_at", ASCENDING), ("used_at", ASCENDING)])
        self.db.attendance_policies.create_index([("academic_period_id", ASCENDING), ("scope", ASCENDING)], unique=True)

    def dashboard(self, start, end, class_id=None, period_id=None, shift=None):
        match = {"date": {"$gte": start, "$lte": end}, "status": {"$in": ["PRESENT", "ABSENT"]}}
        pipeline = [
            {"$match": match},
            {"$lookup": {"from": "enrollments", "localField": "enrollment_id", "foreignField": "_id", "as": "enrollment"}},
            {"$unwind": "$enrollment"},
            {"$lookup": {"from": "classes", "localField": "enrollment.class_id", "foreignField": "_id", "as": "class"}},
            {"$unwind": "$class"},
        ]
        if class_id:
            # O filtro chega da URL como texto; classes._id é ObjectId.
            pipeline.append({"$match": {"class._id": self.object_id(class_id)}})
        if period_id:
            pipeline.append({"$match": {"enrollment.academic_period_id": period_id}})
        if shift:
            pipeline.append({"$match": {"class.shift": shift}})

        by_class = pipeline + [{"$group": {
            "_id": {"id": "$class._id", "name": "$class.name"},
            "distinct_absent_students": {"$addToSet": {"$cond": [{"$eq": ["$status", "ABSENT"]}, "$enrollment.student_id", None]}},
            "absence_occurrences": {"$sum": {"$cond": [{"$eq": ["$status", "ABSENT"]}, 1, 0]}},
            "present_count": {"$sum": {"$cond": [{"$eq": ["$status", "PRESENT"]}, 1, 0]}},
            "valid_attendance_records": {"$sum": 1},
        }}, {"$sort": {"_id.name": 1}}]
        classes = []
        for item in self.db.attendance_records.aggregate(by_class):
            absent = [x for x in item["distinct_absent_students"] if x is not None]
            classes.append({
                "class_id": item["_id"]["id"], "class_name": item["_id"]["name"],
                "distinct_absent_students": len(absent),
                "absence_occurrences": item["absence_occurrences"],
                "presence_percent": round(item["present_count"] / item["valid_attendance_records"] * 100, 2) if item["valid_attendance_records"] else 0,
                "present_count": item["present_count"], "valid_attendance_records": item["valid_attendance_records"],
            })

        overall = {"distinct_absent_students": 0, "absence_occurrences": 0, "present_count": 0, "valid_attendance_records": 0}
        distinct = set()
        for item in self.db.attendance_records.aggregate(pipeline + [{"$group": {
            "_id": None,
            "students": {"$addToSet": {"$cond": [{"$eq": ["$status", "ABSENT"]}, "$enrollment.student_id", None]}},
            "absence_occurrences": {"$sum": {"$cond": [{"$eq": ["$status", "ABSENT"]}, 1, 0]}},
            "present_count": {"$sum": {"$cond": [{"$eq": ["$status", "PRESENT"]}, 1, 0]}},
            "valid_attendance_records": {"$sum": 1},
        }}]):
            distinct = {x for x in item.get("students", []) if x is not None}
            overall.update({"absence_occurrences": item.get("absence_occurrences", 0), "present_count": item.get("present_count", 0), "valid_attendance_records": item.get("valid_attendance_records", 0)})
        overall["distinct_absent_students"] = len(distinct)
        overall["presence_percent"] = round(overall["present_count"] / overall["valid_attendance_records"] * 100, 2) if overall["valid_attendance_records"] else 0

        absence_base = pipeline + [{"$match": {"status": "ABSENT"}}]

        def trend_item(item):
            distinct_students = len(item["students"])
            occurrences = item["absence_occurrences"]
            return {"period": item["_id"], "absence_occurrences": occurrences, "distinct_absent_students": distinct_students, "average_absences_per_student": round(occurrences / distinct_students, 2) if distinct_students else 0}

        absence_trends = {}
        for key, date_format in (("daily", "%Y-%m-%d"), ("monthly", "%Y-%m"), ("yearly", "%Y")):
            absence_trends[key] = [trend_item(item) for item in self.db.attendance_records.aggregate(absence_base + [
                {"$group": {"_id": {"$dateToString": {"format": date_format, "date": "$date"}}, "absence_occurrences": {"$sum": 1}, "students": {"$addToSet": "$enrollment.student_id"}}},
                {"$sort": {"_id": 1}},
            ])]

        # Situação das ocorrências (ausências) do período: sem justificativa conta como pendente.
        status_by_class = {}
        for item in self.db.attendance_records.aggregate(absence_base + [
            {"$lookup": {"from": "justifications", "localField": "_id", "foreignField": "attendance_id", "as": "justification"}},
            {"$unwind": {"path": "$justification", "preserveNullAndEmptyArrays": True}},
            {"$group": {"_id": {"class_id": "$class._id", "status": {"$ifNull": ["$justification.status", "PENDING"]}}, "count": {"$sum": 1}}},
        ]):
            counts = status_by_class.setdefault(item["_id"]["class_id"], {"PENDING": 0, "RESPONDED": 0})
            counts[item["_id"]["status"]] = counts.get(item["_id"]["status"], 0) + item["count"]
        for school_class in classes:
            counts = status_by_class.get(school_class["class_id"], {})
            school_class["pending_occurrences"] = counts.get("PENDING", 0)
            school_class["responded_occurrences"] = counts.get("RESPONDED", 0)
        overall["pending_occurrences"] = sum(c["pending_occurrences"] for c in classes)
        overall["responded_occurrences"] = sum(c["responded_occurrences"] for c in classes)

        totals = {
            "students": self.db.students.count_documents({"active": {"$ne": False}}),
            "guardians": self.db.guardians.count_documents({"active": {"$ne": False}}),
        }
        return {"classes": classes, "overall": overall, "absence_trends": absence_trends, "totals": totals}

    def create_attendance(self, document):
        document.setdefault("created_at", utcnow())
        return self.db.attendance_records.insert_one(document).inserted_id

    def notification_context(self, student_id, attendance_id=None):
        student = self.find_one("students", student_id)
        if not student:
            return None
        student_object_id = self.object_id(student_id)
        guardians = self.student_guardians(student_object_id)
        enrollments = list(self.db.enrollments.find({"student_id": student_object_id}, {"_id": 1}))
        enrollment_ids = [item["_id"] for item in enrollments]
        attendance_query = {"enrollment_id": {"$in": enrollment_ids}, "status": "ABSENT"}
        if attendance_id:
            attendance_query["_id"] = self.object_id(attendance_id)
        absences = list(self.db.attendance_records.find(attendance_query).sort("date", DESCENDING).limit(30))
        return {"student": student, "guardians": guardians, "absences": absences}

    def list_students(self):
        return list(self.db.students.find({"active": True}, {"name": 1, "school_id": 1}).sort("name", ASCENDING))

    def list_classes(self, period_id=None):
        query = {"active": True}
        if period_id:
            query["academic_period_id"] = period_id
        return list(self.db.classes.find(query).sort("name", ASCENDING))

    def list_pending_justifications(self):
        return list(self.db.justifications.find({"status": "PENDING"}).sort("created_at", DESCENDING))

    # ---- Cadastros com tela: alunos, turmas, responsáveis e vínculos ----

    def _active_class(self, class_id):
        school_class = self.db.classes.find_one({"_id": self.object_id(class_id), "active": {"$ne": False}})
        if not school_class:
            raise ValueError("Turma não encontrada ou inativa.")
        return school_class

    def _active_student(self, student_id):
        student = self.db.students.find_one({"_id": self.object_id(student_id), "active": {"$ne": False}})
        if not student:
            raise ValueError("Aluno não encontrado ou inativo.")
        return student

    def set_student_class(self, student_object_id, school_class):
        """Vincula o aluno à turma: ajusta a matrícula do período letivo da turma ou cria uma nova."""
        now = utcnow()
        enrollment = self.db.enrollments.find_one({"student_id": student_object_id, "academic_period_id": school_class["academic_period_id"], "active": {"$ne": False}})
        if enrollment:
            if enrollment["class_id"] != school_class["_id"]:
                self.db.enrollments.update_one({"_id": enrollment["_id"]}, {"$set": {"class_id": school_class["_id"], "updated_at": now}})
            return enrollment["_id"]
        return self.db.enrollments.insert_one({
            "student_id": student_object_id, "class_id": school_class["_id"], "academic_period_id": school_class["academic_period_id"],
            "start_date": now.replace(hour=0, minute=0, second=0, microsecond=0), "end_date": None, "active": True, "created_at": now, "updated_at": now,
        }).inserted_id

    def create_student(self, data):
        school_class = self._active_class(data["class_id"])
        now = utcnow()
        student_id = self.db.students.insert_one({"name": data["name"], "school_id": data["school_id"], "birth_date": data["birth_date"], "active": True, "created_at": now, "updated_at": now}).inserted_id
        self.set_student_class(student_id, school_class)
        return student_id

    def update_student(self, student_id, data):
        student = self._active_student(student_id)
        school_class = self._active_class(data["class_id"])
        self.db.students.update_one({"_id": student["_id"]}, {"$set": {"name": data["name"], "school_id": data["school_id"], "birth_date": data["birth_date"], "updated_at": utcnow()}})
        self.set_student_class(student["_id"], school_class)

    def _classes_by_id(self):
        return {item["_id"]: item for item in self.db.classes.find()}

    def list_students_overview(self):
        classes = self._classes_by_id()
        current = {}
        for enrollment in self.db.enrollments.find({"active": {"$ne": False}}).sort("academic_period_id", ASCENDING):
            current[enrollment["student_id"]] = classes.get(enrollment["class_id"])
        guardian_counts = {}
        for link in self.db.student_guardians.find({"active": {"$ne": False}}):
            guardian_counts[link["student_id"]] = guardian_counts.get(link["student_id"], 0) + 1
        students = list(self.db.students.find({"active": {"$ne": False}}).sort("name", ASCENDING))
        for student in students:
            student["current_class"] = current.get(student["_id"])
            student["guardian_count"] = guardian_counts.get(student["_id"], 0)
        return students

    def student_detail(self, student_id):
        student = self._active_student(student_id)
        classes = self._classes_by_id()
        student["enrollments"] = list(self.db.enrollments.find({"student_id": student["_id"]}).sort("academic_period_id", DESCENDING))
        for enrollment in student["enrollments"]:
            enrollment["class"] = classes.get(enrollment["class_id"])
        current = [e for e in student["enrollments"] if e.get("active") is not False]
        student["current_class"] = current[0]["class"] if current else None
        student["guardians"] = list(self.db.student_guardians.aggregate([
            {"$match": {"student_id": student["_id"], "active": {"$ne": False}}},
            {"$lookup": {"from": "guardians", "localField": "guardian_id", "foreignField": "_id", "as": "guardian"}},
            {"$unwind": "$guardian"},
            {"$sort": {"is_primary": -1, "guardian.name": 1}},
        ]))
        return student

    def create_guardian(self, data):
        now = utcnow()
        return self.db.guardians.insert_one({**data, "email_normalized": data["email"].lower(), "active": True, "created_at": now, "updated_at": now}).inserted_id

    def update_guardian(self, guardian_id, data):
        result = self.db.guardians.update_one({"_id": self.object_id(guardian_id), "active": {"$ne": False}}, {"$set": {**data, "email_normalized": data["email"].lower(), "updated_at": utcnow()}})
        if result.matched_count != 1:
            raise ValueError("Responsável não encontrado.")

    def list_guardians_overview(self):
        students = {s["_id"]: s for s in self.db.students.find({"active": {"$ne": False}}, {"name": 1})}
        linked = {}
        for link in self.db.student_guardians.find({"active": {"$ne": False}}):
            if link["student_id"] in students:
                linked.setdefault(link["guardian_id"], []).append(students[link["student_id"]]["name"])
        guardians = list(self.db.guardians.find({"active": {"$ne": False}}).sort("name", ASCENDING))
        for guardian in guardians:
            guardian["student_names"] = sorted(linked.get(guardian["_id"], []))
        return guardians

    def guardian_detail(self, guardian_id):
        guardian = self.db.guardians.find_one({"_id": self.object_id(guardian_id), "active": {"$ne": False}})
        if not guardian:
            return None
        guardian["students"] = list(self.db.student_guardians.aggregate([
            {"$match": {"guardian_id": guardian["_id"], "active": {"$ne": False}}},
            {"$lookup": {"from": "students", "localField": "student_id", "foreignField": "_id", "as": "student"}},
            {"$unwind": "$student"},
            {"$match": {"student.active": {"$ne": False}}},
            {"$sort": {"student.name": 1}},
        ]))
        return guardian

    def link_guardian(self, student_id, guardian_id, link):
        student = self._active_student(student_id)
        guardian = self.db.guardians.find_one({"_id": self.object_id(guardian_id), "active": {"$ne": False}})
        if not guardian:
            raise ValueError("Responsável não encontrado.")
        now = utcnow()
        if link.get("is_primary"):
            self.db.student_guardians.update_many({"student_id": student["_id"], "guardian_id": {"$ne": guardian["_id"]}}, {"$set": {"is_primary": False, "updated_at": now}})
        self.db.student_guardians.update_one(
            {"student_id": student["_id"], "guardian_id": guardian["_id"]},
            {"$set": {**link, "active": True, "updated_at": now}, "$setOnInsert": {"created_at": now}},
            upsert=True,
        )

    def unlink_guardian(self, student_id, guardian_id):
        result = self.db.student_guardians.update_one(
            {"student_id": self.object_id(student_id), "guardian_id": self.object_id(guardian_id), "active": {"$ne": False}},
            {"$set": {"active": False, "is_primary": False, "updated_at": utcnow()}},
        )
        return result.matched_count == 1

    def create_class(self, data):
        now = utcnow()
        return self.db.classes.insert_one({**data, "active": True, "created_at": now, "updated_at": now}).inserted_id

    def update_class(self, class_id, data):
        school_class = self._active_class(class_id)
        if data["academic_period_id"] != school_class["academic_period_id"] and self.db.enrollments.count_documents({"class_id": school_class["_id"]}):
            raise ValueError("Não é possível mudar o período letivo de uma turma que já tem alunos matriculados.")
        self.db.classes.update_one({"_id": school_class["_id"]}, {"$set": {**data, "updated_at": utcnow()}})

    def list_classes_overview(self):
        counts = {}
        for enrollment in self.db.enrollments.find({"active": {"$ne": False}}):
            counts[enrollment["class_id"]] = counts.get(enrollment["class_id"], 0) + 1
        classes = list(self.db.classes.find({"active": {"$ne": False}}).sort([("academic_period_id", DESCENDING), ("name", ASCENDING)]))
        for school_class in classes:
            school_class["student_count"] = counts.get(school_class["_id"], 0)
        return classes

    def class_detail(self, class_id):
        school_class = self.db.classes.find_one({"_id": self.object_id(class_id), "active": {"$ne": False}})
        if not school_class:
            return None
        enrolled_ids = [e["student_id"] for e in self.db.enrollments.find({"class_id": school_class["_id"], "active": {"$ne": False}})]
        school_class["students"] = list(self.db.students.find({"_id": {"$in": enrolled_ids}, "active": {"$ne": False}}).sort("name", ASCENDING))
        return school_class

    def add_student_to_class(self, class_id, student_id):
        self.set_student_class(self._active_student(student_id)["_id"], self._active_class(class_id))

    def list_users(self, search=None):
        query = {}
        if search:
            pattern = {"$regex": re.escape(search.strip()), "$options": "i"}
            query["$or"] = [{"name": pattern}, {"email_normalized": pattern}]
        return list(self.db.users.find(query, {"password_hash": 0}).sort("name", ASCENDING))

    # ---- Recuperação de senha (#32) ----
    PASSWORD_RESET_TTL = timedelta(hours=1)
    PASSWORD_RESET_LIMIT_PER_HOUR = 3

    @staticmethod
    def _token_hash(raw_token):
        return hashlib.sha256(raw_token.encode("utf-8")).hexdigest()

    def create_password_reset(self, email, allowed_profiles):
        """Gera o token de redefinição. Retorna (usuário, token) ou None quando não deve haver envio
        (e-mail desconhecido, usuário inativo/sem login ou limite de pedidos atingido)."""
        user = self.db.users.find_one({"email_normalized": (email or "").strip().lower(), "active": True, "profile": {"$in": list(allowed_profiles)}})
        if not user:
            return None
        now = utcnow()
        if self.db.password_resets.count_documents({"user_id": user["_id"], "created_at": {"$gte": now - timedelta(hours=1)}}) >= self.PASSWORD_RESET_LIMIT_PER_HOUR:
            return None
        # Só o link mais recente vale.
        self.db.password_resets.update_many({"user_id": user["_id"], "used_at": None}, {"$set": {"used_at": now, "invalidated": True}})
        raw_token = secrets.token_urlsafe(32)
        self.db.password_resets.insert_one({"user_id": user["_id"], "token_hash": self._token_hash(raw_token), "expires_at": now + self.PASSWORD_RESET_TTL, "used_at": None, "created_at": now})
        return user, raw_token

    def find_password_reset(self, raw_token):
        reset = self.db.password_resets.find_one({"token_hash": self._token_hash(raw_token), "used_at": None})
        if not reset or reset["expires_at"].replace(tzinfo=timezone.utc) <= utcnow():
            return None
        user = self.db.users.find_one({"_id": reset["user_id"], "active": True})
        return reset if user else None

    def reset_password(self, raw_token, new_password):
        reset = self.find_password_reset(raw_token)
        if not reset:
            return False
        now = utcnow()
        # Marca o token antes de trocar a senha, para que dois envios simultâneos não usem o mesmo link.
        claimed = self.db.password_resets.update_one({"_id": reset["_id"], "used_at": None}, {"$set": {"used_at": now}})
        if claimed.modified_count != 1:
            return False
        self.db.users.update_one({"_id": reset["user_id"]}, {
            "$set": {"password_hash": generate_password_hash(new_password), "password_changed_at": now, "updated_at": now},
            "$inc": {"session_version": 1},
        })
        return True

    def get_user(self, user_id):
        return self.db.users.find_one({"_id": self.object_id(user_id)}, {"password_hash": 0})

    def update_user_access(self, user_id, profile, active):
        """Associa o usuário a um perfil e ativa/desativa o acesso, sem deixar o sistema sem administrador."""
        user = self.get_user(user_id)
        if not user:
            raise ValueError("Usuário não encontrado.")
        if user.get("profile") == "ADMIN" and user.get("active") and (profile != "ADMIN" or not active):
            if self.db.users.count_documents({"profile": "ADMIN", "active": True}) <= 1:
                raise ValueError("O sistema precisa de pelo menos um administrador ativo.")
        self.db.users.update_one({"_id": user["_id"]}, {"$set": {"profile": profile, "active": active, "updated_at": utcnow()}})

    def student_guardians(self, student_object_id, only_notifiable=False):
        link_match = {"student_id": student_object_id, "active": {"$ne": False}}
        if only_notifiable:
            link_match["receives_absence_notifications"] = {"$ne": False}
        return list(self.db.student_guardians.aggregate([
            {"$match": link_match},
            {"$lookup": {"from": "guardians", "localField": "guardian_id", "foreignField": "_id", "as": "guardian"}},
            {"$unwind": "$guardian"},
            {"$match": {"guardian.active": {"$ne": False}, "guardian.email_normalized": {"$exists": True}}},
            {"$project": {"_id": 0, "guardian_id": "$guardian._id", "name": "$guardian.name", "email": "$guardian.email_normalized", "is_primary": {"$ifNull": ["$is_primary", False]}}},
            {"$sort": {"is_primary": -1, "name": 1}},
        ]))

    def find_active_enrollment(self, student_object_id, date):
        """Matrícula ativa do aluno cuja vigência inclui a data da ausência."""
        candidates = self.db.enrollments.find({"student_id": student_object_id, "active": {"$ne": False}}).sort("start_date", DESCENDING)
        for enrollment in candidates:
            start, end = enrollment.get("start_date"), enrollment.get("end_date")
            if start and start.replace(tzinfo=timezone.utc) > date:
                continue
            if end and end.replace(tzinfo=timezone.utc) < date:
                continue
            return enrollment
        return None

    def register_absence(self, student_id, date, user_id, notes=""):
        """Registra a ausência e abre a ocorrência com status PENDING.

        Lança ValueError para dados inválidos e DuplicateKeyError se já houver
        frequência para a matrícula na data.
        """
        student = self.db.students.find_one({"_id": self.object_id(student_id), "active": {"$ne": False}})
        if not student:
            raise ValueError("Aluno não encontrado ou inativo.")
        if date > utcnow():
            raise ValueError("A data da ausência não pode estar no futuro.")
        enrollment = self.find_active_enrollment(student["_id"], date)
        if not enrollment:
            raise ValueError("O aluno não possui matrícula ativa na data informada.")
        now = utcnow()
        attendance_id = self.db.attendance_records.insert_one({
            "enrollment_id": enrollment["_id"],
            "date": date,
            "status": "ABSENT",
            "registered_by": user_id,
            "notes": notes,
            "created_at": now,
            "updated_at": now,
        }).inserted_id
        self.db.justifications.insert_one({
            "attendance_id": attendance_id,
            "student_id": student["_id"],
            "status": "PENDING",
            "status_history": [{"status": "PENDING", "at": now, "by": user_id, "note": "Ausência registrada"}],
            "created_at": now,
            "updated_at": now,
        })
        school_class = self.db.classes.find_one({"_id": enrollment.get("class_id")}) or {}
        return {"attendance_id": attendance_id, "student": student, "class_name": school_class.get("name"), "date": date}

    def _occurrence_pipeline(self, match):
        return [
            {"$match": match},
            {"$lookup": {"from": "enrollments", "localField": "enrollment_id", "foreignField": "_id", "as": "enrollment"}},
            {"$unwind": "$enrollment"},
            {"$lookup": {"from": "students", "localField": "enrollment.student_id", "foreignField": "_id", "as": "student"}},
            {"$unwind": "$student"},
            {"$lookup": {"from": "classes", "localField": "enrollment.class_id", "foreignField": "_id", "as": "class"}},
            {"$unwind": {"path": "$class", "preserveNullAndEmptyArrays": True}},
            {"$lookup": {"from": "justifications", "localField": "_id", "foreignField": "attendance_id", "as": "justification"}},
            {"$unwind": {"path": "$justification", "preserveNullAndEmptyArrays": True}},
            # Ausências anteriores ao controle de status não têm justificativa: contam como pendentes.
            {"$addFields": {"occurrence_status": {"$ifNull": ["$justification.status", "PENDING"]}}},
        ]

    def list_occurrences(self, student_id=None, class_id=None, status=None, limit=200):
        pipeline = self._occurrence_pipeline({"status": "ABSENT"})
        if student_id:
            pipeline.append({"$match": {"student._id": self.object_id(student_id)}})
        if class_id:
            pipeline.append({"$match": {"class._id": self.object_id(class_id)}})
        if status:
            if status not in {"PENDING", "RESPONDED"}:
                raise ValueError("Status inválido.")
            pipeline.append({"$match": {"occurrence_status": status}})
        pipeline += [{"$sort": {"date": -1, "student.name": 1}}, {"$limit": limit}]
        return list(self.db.attendance_records.aggregate(pipeline))

    def occurrence_detail(self, attendance_id):
        items = list(self.db.attendance_records.aggregate(self._occurrence_pipeline({"_id": self.object_id(attendance_id), "status": "ABSENT"})))
        if not items:
            return None
        occurrence = items[0]
        occurrence["notifications"] = list(self.db.email_notifications.find({"attendance_id": occurrence["_id"]}).sort("created_at", DESCENDING))
        return occurrence

    def authenticate_user(self, email, password, allowed_profiles=None):
        query = {"email_normalized": email.strip().lower(), "active": True}
        if allowed_profiles:
            query["profile"] = {"$in": allowed_profiles}
        user = self.db.users.find_one(query)
        if not user or not user.get("password_hash") or not check_password_hash(user["password_hash"], password):
            return None
        self.db.users.update_one({"_id": user["_id"]}, {"$set": {"last_login_at": utcnow()}})
        user.pop("password_hash", None)
        return user

    def create_internal_user(self, name, email, password, profile):
        if profile not in LOGIN_PROFILES:
            raise ValueError(f"Perfil inválido. Use {', '.join(LOGIN_PROFILES)}.")
        if len(password) < 8:
            raise ValueError("A senha deve possuir pelo menos 8 caracteres.")
        now = utcnow()
        return self.db.users.insert_one({
            "name": name.strip(),
            "email": email.strip(),
            "email_normalized": email.strip().lower(),
            "password_hash": generate_password_hash(password),
            "profile": profile,
            "active": True,
            "created_at": now,
            "updated_at": now,
        }).inserted_id

    def find_justification_link(self, raw_token):
        token_hash = hashlib.sha256(raw_token.encode("utf-8")).hexdigest()
        link = self.db.justification_links.find_one({
            "token_hash": token_hash,
            "used_at": {"$exists": False},
            "expires_at": {"$gt": utcnow()},
            "active": True,
        })
        return link

    def create_justification_link(self, attendance_id, guardian_id, expires_at):
        raw_token = secrets.token_urlsafe(32)
        self.db.justification_links.insert_one({
            "token_hash": hashlib.sha256(raw_token.encode("utf-8")).hexdigest(),
            "attendance_id": attendance_id,
            "guardian_id": guardian_id,
            "expires_at": expires_at,
            "active": True,
            "created_at": utcnow(),
        })
        # O token puro só é devolvido para a camada que enviará o e-mail; não é salvo.
        return raw_token

    def submit_public_justification(self, raw_token, reason, explanation):
        link = self.find_justification_link(raw_token)
        if not link:
            return False, "Link inválido, expirado ou já utilizado."
        now = utcnow()
        result = self.db.justifications.update_one(
            {"attendance_id": link["attendance_id"]},
            {"$set": {"attendance_id": link["attendance_id"], "guardian_id": link.get("guardian_id"), "reason": reason, "explanation": explanation, "status": "RESPONDED", "submitted_at": now, "updated_at": now},
             "$push": {"status_history": {"status": "RESPONDED", "at": now, "by": link.get("guardian_id"), "note": "Justificativa enviada pelo responsável"}},
             "$setOnInsert": {"created_at": now}},
            upsert=True,
        )
        self.db.justification_links.update_one({"_id": link["_id"], "used_at": {"$exists": False}}, {"$set": {"used_at": now}})
        return True, str(result.upserted_id or link["attendance_id"])
