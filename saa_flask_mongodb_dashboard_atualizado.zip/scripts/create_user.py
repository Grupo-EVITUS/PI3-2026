#!/usr/bin/env python3
import argparse
import getpass
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from pymongo.errors import DuplicateKeyError
from models.saa_model import SAARepository


def main():
    parser = argparse.ArgumentParser(description="Cadastra um usuário interno do SAA.")
    parser.add_argument("--name", required=True, help="Nome completo")
    parser.add_argument("--email", required=True, help="E-mail de login")
    parser.add_argument("--profile", required=True, choices=["AOE", "COORDINATION", "ADMIN"], help="Perfil interno")
    args = parser.parse_args()

    password = getpass.getpass("Senha (mínimo 8 caracteres): ")
    confirmation = getpass.getpass("Confirme a senha: ")
    if password != confirmation:
        parser.error("As senhas não coincidem.")

    repository = SAARepository()
    try:
        repository.ensure_indexes()
        identifier = repository.create_internal_user(args.name, args.email, password, args.profile)
        print(f"Usuário criado com sucesso. ID: {identifier}")
        print(f"Perfil: {args.profile}")
        print(f"Login: {args.email.strip().lower()}")
    except DuplicateKeyError:
        parser.error("Já existe um usuário com este e-mail.")
    except ValueError as exc:
        parser.error(str(exc))
    finally:
        repository.close()


if __name__ == "__main__":
    main()
