"""Perfis de usuário e permissões do SAA (issues #31 e #50).

Toda verificação de acesso passa por `can(profile, permission)`; as rotas
declaram a permissão exigida e a tela esconde o que o perfil não pode usar.
"""

PROFILES = {
    "ADMIN": {
        "label": "Administrador",
        "description": "Acesso completo, inclusive cadastro de usuários e definição de perfis.",
        "login": True,
    },
    "COORDINATION": {
        "label": "Coordenador",
        "description": "Acompanha indicadores e ocorrências, registra ausências e envia comunicações. Consulta os cadastros sem alterá-los.",
        "login": True,
    },
    "AOE": {
        "label": "AOE",
        "description": "Agente de Organização Escolar: registra ausências, envia comunicações e mantém os cadastros.",
        "login": True,
    },
    "SECRETARY": {
        "label": "Secretária",
        "description": "Mantém os cadastros de alunos, turmas e responsáveis.",
        "login": True,
    },
    "GUARDIAN": {
        "label": "Responsável",
        "description": "Não acessa a área interna. Recebe o e-mail de ausência e justifica pelo link individual, sem senha.",
        "login": False,
    },
}

PERMISSIONS = {
    "dashboard.view": "Ver o painel de indicadores",
    "absences.register": "Registrar ausências",
    "occurrences.view": "Consultar ocorrências e justificativas",
    "communications.send": "Enviar comunicações por e-mail",
    "registry.view": "Consultar alunos, turmas e responsáveis",
    "registry.edit": "Cadastrar e alterar alunos, turmas e responsáveis",
    "users.manage": "Cadastrar usuários e definir perfis",
    "justification.submit": "Enviar justificativa pelo link recebido por e-mail",
}

GRANTS = {
    "ADMIN": set(PERMISSIONS) - {"justification.submit"},
    "COORDINATION": {"dashboard.view", "absences.register", "occurrences.view", "communications.send", "registry.view"},
    "AOE": {"dashboard.view", "absences.register", "occurrences.view", "communications.send", "registry.view", "registry.edit"},
    "SECRETARY": {"registry.view", "registry.edit"},
    "GUARDIAN": {"justification.submit"},
}

LOGIN_PROFILES = [code for code, profile in PROFILES.items() if profile["login"]]

# Primeira página de cada perfil após o login, na ordem de preferência.
HOME_PAGES = [("dashboard.view", "dashboard"), ("occurrences.view", "occurrences"), ("registry.view", "students")]


def can(profile, permission):
    if permission not in PERMISSIONS:
        raise KeyError(f"Permissão desconhecida: {permission}")
    return permission in GRANTS.get(profile, set())


def home_endpoint(profile):
    for permission, endpoint in HOME_PAGES:
        if can(profile, permission):
            return endpoint
    return "my_profile"


def profile_label(profile):
    return PROFILES.get(profile, {}).get("label", profile or "—")
