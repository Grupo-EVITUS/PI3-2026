"""Envio de e-mails do SAA.

Configuração por variáveis de ambiente:

- EMAIL_BACKEND: "smtp" (padrão) ou "console" (apenas imprime no terminal; útil em desenvolvimento).
- SMTP_HOST, SMTP_PORT (padrão 587), SMTP_USER, SMTP_PASSWORD
- SMTP_FROM: remetente; se ausente, usa SMTP_USER.
- SMTP_STARTTLS: "true" (padrão) ou "false".
"""
from email.message import EmailMessage
import os
import smtplib


class EmailSendError(Exception):
    """Falha que deve ser registrada como FAILED na notificação."""


def send_email(recipient, subject, body):
    backend = os.getenv("EMAIL_BACKEND", "smtp").strip().lower()
    if backend == "console":
        print(f"[EMAIL console] Para: {recipient}\nAssunto: {subject}\n\n{body}\n")
        return
    if backend != "smtp":
        raise EmailSendError(f"EMAIL_BACKEND desconhecido: {backend}.")

    host = os.getenv("SMTP_HOST")
    if not host:
        raise EmailSendError("Servidor SMTP não configurado (defina SMTP_HOST).")
    user = os.getenv("SMTP_USER")
    sender = os.getenv("SMTP_FROM") or user
    if not sender:
        raise EmailSendError("Remetente não configurado (defina SMTP_FROM ou SMTP_USER).")

    message = EmailMessage()
    message["From"] = sender
    message["To"] = recipient
    message["Subject"] = subject
    message.set_content(body)

    try:
        with smtplib.SMTP(host, int(os.getenv("SMTP_PORT", "587")), timeout=15) as smtp:
            if os.getenv("SMTP_STARTTLS", "true").lower() != "false":
                smtp.starttls()
            if user:
                smtp.login(user, os.getenv("SMTP_PASSWORD", ""))
            smtp.send_message(message)
    except (OSError, smtplib.SMTPException) as exc:
        raise EmailSendError(f"Falha no envio SMTP: {exc}") from exc
