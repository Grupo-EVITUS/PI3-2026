from datetime import datetime, timezone

import mongomock
import pytest

import app as app_module
from models.saa_model import SAARepository


class MockRepository(SAARepository):
    def __init__(self, client):
        self.client = client
        self.db = client["saa_test"]

    def close(self):
        pass


@pytest.fixture
def db_client(monkeypatch):
    client = mongomock.MongoClient()
    monkeypatch.setattr(app_module, "repo", lambda: MockRepository(client))
    monkeypatch.delenv("SMTP_HOST", raising=False)
    monkeypatch.setenv("EMAIL_BACKEND", "console")
    return client


@pytest.fixture
def seed(db_client):
    db = db_client["saa_test"]
    MockRepository(db_client).ensure_indexes()
    user_id = db.users.insert_one({"name": "AOE", "email_normalized": "aoe@escola.com", "profile": "AOE", "active": True}).inserted_id
    class_id = db.classes.insert_one({"name": "6º A", "academic_period_id": "2026", "code": "6A", "active": True}).inserted_id
    other_class_id = db.classes.insert_one({"name": "7º B", "academic_period_id": "2026", "code": "7B", "active": True}).inserted_id
    student_id = db.students.insert_one({"name": "Ana Souza", "school_id": "M001", "active": True}).inserted_id
    other_student_id = db.students.insert_one({"name": "Bruno Lima", "school_id": "M002", "active": True}).inserted_id
    no_enrollment_id = db.students.insert_one({"name": "Caio Sem Matrícula", "school_id": "M003", "active": True}).inserted_id
    start = datetime(2026, 2, 1, tzinfo=timezone.utc)
    db.enrollments.insert_one({"student_id": student_id, "class_id": class_id, "academic_period_id": "2026", "start_date": start, "end_date": None, "active": True})
    db.enrollments.insert_one({"student_id": other_student_id, "class_id": other_class_id, "academic_period_id": "2026", "start_date": start, "end_date": None, "active": True})
    guardian_id = db.guardians.insert_one({"name": "Carlos Souza", "email": "Carlos@Exemplo.com", "email_normalized": "carlos@exemplo.com", "active": True}).inserted_id
    db.student_guardians.insert_one({"student_id": student_id, "guardian_id": guardian_id, "is_primary": True, "active": True})
    return {"db": db, "user_id": user_id, "class_id": class_id, "other_class_id": other_class_id, "student_id": student_id, "other_student_id": other_student_id, "no_enrollment_id": no_enrollment_id, "guardian_id": guardian_id}


@pytest.fixture
def client(seed):
    app_module.app.config.update(TESTING=True)
    test_client = app_module.app.test_client()
    with test_client.session_transaction() as sess:
        sess["user_id"] = str(seed["user_id"])
        sess["user_name"] = "AOE Teste"
        sess["profile"] = "AOE"
    return test_client


@pytest.fixture
def login_as(client, seed):
    """Troca o perfil do usuário logado no banco (o perfil é relido a cada requisição)."""
    def change(profile):
        seed["db"].users.update_one({"_id": seed["user_id"]}, {"$set": {"profile": profile}})
        return client
    return change
