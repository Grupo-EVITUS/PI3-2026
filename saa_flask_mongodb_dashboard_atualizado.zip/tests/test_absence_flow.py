from datetime import datetime, timedelta, timezone

import app as app_module


def yesterday():
    return (datetime.now(timezone.utc) - timedelta(days=1)).strftime("%Y-%m-%d")


def register(client, student_id, date=None):
    return client.post("/absences", data={"student_id": str(student_id), "date": date or yesterday(), "notes": "Informada pela professora"})


def test_registro_cria_ausencia_ocorrencia_pendente_e_envia_email(client, seed):
    db = seed["db"]
    response = register(client, seed["student_id"])
    assert response.status_code == 200
    assert "Ocorrência aberta como Pendente" in response.get_data(as_text=True)

    attendance = db.attendance_records.find_one()
    assert attendance["status"] == "ABSENT"
    assert attendance["notes"] == "Informada pela professora"

    justification = db.justifications.find_one({"attendance_id": attendance["_id"]})
    assert justification["status"] == "PENDING"
    assert [h["status"] for h in justification["status_history"]] == ["PENDING"]

    notification = db.email_notifications.find_one()
    assert notification["status"] == "SENT"
    assert notification["attendance_id"] == attendance["_id"]
    assert notification["recipient_email"] == "carlos@exemplo.com"
    assert "Ana Souza" in notification["body"] and "6º A" in notification["body"]
    assert "/justify/" in notification["justification_url"]
    assert db.justification_links.count_documents({"attendance_id": attendance["_id"]}) == 1


def test_falha_de_envio_fica_registrada_sem_perder_a_ausencia(client, seed, monkeypatch):
    monkeypatch.delenv("EMAIL_BACKEND")
    response = register(client, seed["student_id"])
    assert response.status_code == 200
    assert seed["db"].attendance_records.count_documents({}) == 1
    notification = seed["db"].email_notifications.find_one()
    assert notification["status"] == "FAILED"
    assert "SMTP_HOST" in notification["failure_detail"]


def test_ausencia_duplicada_retorna_409(client, seed):
    register(client, seed["student_id"])
    response = register(client, seed["student_id"])
    assert response.status_code == 409
    assert seed["db"].attendance_records.count_documents({}) == 1


def test_validacoes_do_registro(client, seed):
    future = (datetime.now(timezone.utc) + timedelta(days=2)).strftime("%Y-%m-%d")
    assert register(client, seed["student_id"], future).status_code == 400
    assert register(client, seed["no_enrollment_id"]).status_code == 400
    assert register(client, seed["student_id"], "31/12/2025").status_code == 400
    assert client.post("/absences", data={"student_id": "", "date": yesterday()}).status_code == 400
    assert seed["db"].attendance_records.count_documents({}) == 0


def test_justificativa_muda_status_para_respondida_com_historico(client, seed):
    db = seed["db"]
    register(client, seed["student_id"])
    token = db.email_notifications.find_one()["justification_url"].rsplit("/", 1)[1]

    response = client.post(f"/justify/{token}", data={"reason": "DOENCA", "explanation": "Febre"})
    assert response.status_code == 200

    justification = db.justifications.find_one()
    assert justification["status"] == "RESPONDED"
    assert justification["reason"] == "DOENCA"
    assert [h["status"] for h in justification["status_history"]] == ["PENDING", "RESPONDED"]
    # Link de uso único.
    assert client.post(f"/justify/{token}", data={"reason": "DOENCA"}).status_code == 410


def test_consulta_de_ocorrencias_por_status_turma_e_aluno(client, seed):
    db = seed["db"]
    register(client, seed["student_id"])
    register(client, seed["other_student_id"])
    token = db.email_notifications.find_one({"student_id": seed["student_id"]})["justification_url"].rsplit("/", 1)[1]
    client.post(f"/justify/{token}", data={"reason": "TRANSPORTE"})

    def names(query):
        response = client.get("/occurrences" + query)
        assert response.status_code == 200
        html = response.get_data(as_text=True)
        # Nomes em <b> são as linhas da tabela; o filtro de aluno também lista os nomes.
        return {name for name in ("Ana Souza", "Bruno Lima") if f"<b>{name}</b>" in html}

    assert names("") == {"Ana Souza", "Bruno Lima"}
    assert names("?status=PENDING") == {"Bruno Lima"}
    assert names("?status=RESPONDED") == {"Ana Souza"}
    assert names(f"?class_id={seed['other_class_id']}") == {"Bruno Lima"}
    assert names(f"?student_id={seed['student_id']}") == {"Ana Souza"}
    assert client.get("/occurrences?status=XYZ").status_code == 400
    assert client.get("/occurrences?class_id=invalido").status_code == 400


def test_ausencia_antiga_sem_justificativa_aparece_como_pendente(client, seed):
    db = seed["db"]
    enrollment = db.enrollments.find_one({"student_id": seed["student_id"]})
    db.attendance_records.insert_one({"enrollment_id": enrollment["_id"], "date": datetime(2026, 3, 2, tzinfo=timezone.utc), "status": "ABSENT"})
    html = client.get("/occurrences?status=PENDING").get_data(as_text=True)
    assert "<b>Ana Souza</b>" in html and "02/03/2026" in html


def test_detalhe_da_ocorrencia(client, seed):
    register(client, seed["student_id"])
    attendance_id = seed["db"].attendance_records.find_one()["_id"]
    response = client.get(f"/occurrences/{attendance_id}")
    html = response.get_data(as_text=True)
    assert response.status_code == 200
    assert "Ana Souza" in html and "carlos@exemplo.com" in html and "Ausência registrada" in html
    assert client.get("/occurrences/652f1b2c3d4e5f6a7b8c9d0e").status_code == 404
    assert client.get("/occurrences/invalido").status_code == 400


def test_disparo_manual_usa_email_cadastrado_do_responsavel(client, seed):
    db = seed["db"]
    register(client, seed["student_id"])
    attendance_id = db.attendance_records.find_one()["_id"]
    response = client.post("/email-dispatch", data={
        "student_id": str(seed["student_id"]),
        "attendance_id": str(attendance_id),
        "guardian_id": str(seed["guardian_id"]),
        "recipient_email": "outra-pessoa@exemplo.com",
        "subject": "Lembrete",
        "body": "Ainda aguardamos a justificativa.",
    })
    assert response.status_code == 200
    manual = db.email_notifications.find_one({"subject": "Lembrete"})
    assert manual["recipient_email"] == "carlos@exemplo.com"
    assert manual["status"] == "SENT"
    assert manual["attendance_id"] == attendance_id


def test_rotas_exigem_login(seed):
    anonymous = app_module.app.test_client()
    for path in ("/absences", "/occurrences"):
        assert anonymous.get(path).status_code == 302
