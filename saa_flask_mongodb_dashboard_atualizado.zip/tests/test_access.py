import pytest

import app as app_module
from models.saa_model import SAARepository
from services.access import LOGIN_PROFILES, PROFILES, can, home_endpoint


def repository(db):
    r = SAARepository.__new__(SAARepository)
    r.db = db
    return r


def routes(seed):
    sid, cid, gid = seed["student_id"], seed["class_id"], seed["guardian_id"]
    return [
        ("GET", "/dashboard", "dashboard.view"),
        ("GET", "/api/dashboard", "dashboard.view"),
        ("GET", "/students", "registry.view"),
        ("POST", "/students", "registry.edit"),
        ("GET", f"/students/{sid}", "registry.view"),
        ("POST", f"/students/{sid}", "registry.edit"),
        ("POST", f"/students/{sid}/guardians", "registry.edit"),
        ("POST", f"/students/{sid}/guardians/{gid}/remove", "registry.edit"),
        ("GET", "/classes", "registry.view"),
        ("POST", "/classes", "registry.edit"),
        ("GET", f"/classes/{cid}", "registry.view"),
        ("POST", f"/classes/{cid}/students", "registry.edit"),
        ("GET", "/guardians", "registry.view"),
        ("POST", "/guardians", "registry.edit"),
        ("GET", f"/guardians/{gid}", "registry.view"),
        ("GET", "/absences", "absences.register"),
        ("POST", "/absences", "absences.register"),
        ("POST", "/attendance", "absences.register"),
        ("GET", "/occurrences", "occurrences.view"),
        ("GET", "/email-dispatch", "communications.send"),
        ("GET", f"/api/notification-context?student_id={sid}", "communications.send"),
        ("GET", "/users", "users.manage"),
        ("POST", "/users", "users.manage"),
        ("POST", f"/users/{seed['user_id']}/access", "users.manage"),
        ("GET", "/api/students", "registry.view"),
        ("POST", "/api/students", "registry.edit"),
        ("DELETE", f"/api/guardians/{gid}", "registry.edit"),
        ("GET", "/api/attendance", "occurrences.view"),
        ("POST", "/api/attendance", "absences.register"),
        ("GET", "/api/notifications", "communications.send"),
    ]


@pytest.mark.parametrize("profile", LOGIN_PROFILES)
def test_matriz_de_permissoes_nas_rotas(login_as, seed, profile):
    client = login_as(profile)
    wrong = []
    for method, path, permission in routes(seed):
        status = client.open(path, method=method, data={}).status_code
        allowed = can(profile, permission)
        if (status == 403) == allowed:
            wrong.append(f"{method} {path} -> {status} (permitido={allowed})")
    assert wrong == []


def test_perfis_exigidos_pela_issue():
    labels = {item["label"] for item in PROFILES.values()}
    assert {"Administrador", "Coordenador", "Secretária", "Responsável"} <= labels
    assert "GUARDIAN" not in LOGIN_PROFILES
    assert can("GUARDIAN", "justification.submit") and not can("GUARDIAN", "registry.view")
    assert not can("COORDINATION", "registry.edit") and can("SECRETARY", "registry.edit")
    assert not can("SECRETARY", "dashboard.view")
    with pytest.raises(KeyError):
        can("ADMIN", "permissao.inexistente")


def test_responsavel_nao_entra_na_area_interna(client, seed):
    db = seed["db"]
    repo = repository(db)
    with pytest.raises(ValueError):
        repo.create_internal_user("Pai", "pai@x.com", "segura123", "GUARDIAN")
    # Mesmo que um usuário GUARDIAN exista no banco, a sessão é encerrada.
    db.users.update_one({"_id": seed["user_id"]}, {"$set": {"profile": "GUARDIAN"}})
    response = client.get("/students")
    assert response.status_code == 302 and "/login" in response.headers["Location"]


def test_usuario_desativado_perde_acesso_na_hora(client, seed):
    assert client.get("/students").status_code == 200
    seed["db"].users.update_one({"_id": seed["user_id"]}, {"$set": {"active": False}})
    response = client.get("/students")
    assert response.status_code == 302 and "/login" in response.headers["Location"]


def test_mudanca_de_perfil_vale_na_proxima_requisicao(login_as):
    client = login_as("AOE")
    assert client.get("/dashboard").status_code == 200
    login_as("SECRETARY")
    assert client.get("/dashboard").status_code == 403


@pytest.mark.parametrize("profile, home", [("ADMIN", "/dashboard"), ("COORDINATION", "/dashboard"), ("AOE", "/dashboard"), ("SECRETARY", "/students")])
def test_login_leva_para_a_pagina_inicial_do_perfil(seed, profile, home):
    repository(seed["db"]).create_internal_user("Teste", f"login-{profile.lower()}@escola.com", "segura123", profile)
    client = app_module.app.test_client()
    response = client.post("/login", data={"email": f"login-{profile.lower()}@escola.com", "password": "segura123"})
    assert response.status_code == 302 and response.headers["Location"].endswith(home)
    assert home_endpoint(profile) in ("dashboard", "students")
    assert client.get("/").headers["Location"].endswith(home)


@pytest.mark.parametrize("target", ["//evil.example.com", "https://evil.example.com", "/\\evil.example.com"])
def test_login_nao_redireciona_para_outro_site(seed, target):
    repository(seed["db"]).create_internal_user("Teste", "t@escola.com", "segura123", "AOE")
    response = app_module.app.test_client().post("/login", data={"email": "t@escola.com", "password": "segura123", "next": target})
    assert response.headers["Location"].endswith("/dashboard")


def test_login_respeita_next_interno(seed):
    repository(seed["db"]).create_internal_user("Teste", "t@escola.com", "segura123", "AOE")
    response = app_module.app.test_client().post("/login", data={"email": "t@escola.com", "password": "segura123", "next": "/occurrences?status=PENDING"})
    assert response.headers["Location"].endswith("/occurrences?status=PENDING")


def test_admin_associa_usuario_a_perfil(login_as, seed):
    client = login_as("ADMIN")
    db = seed["db"]
    other = repository(db).create_internal_user("Fernanda", "fernanda@escola.com", "segura123", "AOE")
    response = client.post(f"/users/{other}/access", data={"profile": "SECRETARY", "active": "on"}, follow_redirects=True)
    assert "Perfil e situação do usuário atualizados." in response.get_data(as_text=True)
    assert db.users.find_one({"_id": other})["profile"] == "SECRETARY"

    client.post(f"/users/{other}/access", data={"profile": "SECRETARY"})
    assert db.users.find_one({"_id": other})["active"] is False

    response = client.post(f"/users/{other}/access", data={"profile": "GUARDIAN", "active": "on"}, follow_redirects=True)
    assert "Perfil inválido" in response.get_data(as_text=True)


def test_admin_nao_remove_o_proprio_acesso(login_as, seed):
    client = login_as("ADMIN")
    response = client.post(f"/users/{seed['user_id']}/access", data={"profile": "AOE", "active": "on"}, follow_redirects=True)
    assert "não pode remover o seu próprio acesso" in response.get_data(as_text=True)
    assert seed["db"].users.find_one({"_id": seed["user_id"]})["profile"] == "ADMIN"


def test_sistema_mantem_ao_menos_um_administrador(seed):
    db = seed["db"]
    repo = repository(db)
    db.users.update_one({"_id": seed["user_id"]}, {"$set": {"profile": "ADMIN"}})
    with pytest.raises(ValueError, match="pelo menos um administrador"):
        repo.update_user_access(seed["user_id"], "AOE", True)
    second = repo.create_internal_user("Outro Admin", "admin2@escola.com", "segura123", "ADMIN")
    repo.update_user_access(seed["user_id"], "AOE", True)
    assert db.users.find_one({"_id": seed["user_id"]})["profile"] == "AOE"
    with pytest.raises(ValueError):
        repo.update_user_access(second, "ADMIN", False)


def test_consulta_de_perfis_e_meu_perfil(login_as):
    client = login_as("SECRETARY")
    html = client.get("/profiles").get_data(as_text=True)
    for label in ("Administrador", "Coordenador", "AOE", "Secretária", "Responsável", "Sem login", "Seu perfil"):
        assert label in html
    html = client.get("/me").get_data(as_text=True)
    assert "Secretária" in html and "Cadastrar e alterar alunos" in html and "Ver o painel" not in html


def test_menu_e_telas_seguem_o_perfil(login_as, seed):
    client = login_as("SECRETARY")
    html = client.get("/students").get_data(as_text=True)
    assert "Novo aluno" in html and "Visão geral" not in html and "Usuários" not in html and ">Ocorrências<" not in html

    client = login_as("COORDINATION")
    html = client.get("/students").get_data(as_text=True)
    assert "Novo aluno" not in html and "Visão geral" in html
    html = client.get(f"/students/{seed['student_id']}").get_data(as_text=True)
    assert "disabled" in html and "Salvar alterações" not in html and "Remover vínculo" not in html

    html = login_as("ADMIN").get("/dashboard").get_data(as_text=True)
    assert "Usuários" in html


def test_acesso_negado_explica_o_motivo(login_as):
    response = login_as("SECRETARY").get("/dashboard")
    html = response.get_data(as_text=True)
    assert response.status_code == 403
    assert "Secretária" in html and "ver o painel de indicadores" in html
