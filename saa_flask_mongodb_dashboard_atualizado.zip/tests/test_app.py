import pytest


def test_app_import_and_routes():
    from app import app
    app.config.update(TESTING=True)
    client = app.test_client()
    assert app.url_map.bind('').match('/dashboard', method='GET')[0] == 'dashboard'
    assert app.url_map.bind('').match('/justify/token-demo', method='GET')[0] == 'justification_form'
