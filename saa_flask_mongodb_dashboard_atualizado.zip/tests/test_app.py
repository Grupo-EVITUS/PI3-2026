import pytest


def test_app_import_and_routes():
    from app import app
    app.config.update(TESTING=True)
    client = app.test_client()
    assert app.url_map.bind('').match('/dashboard', method='GET')[0] == 'dashboard'
    assert app.url_map.bind('').match('/justify/token-demo', method='GET')[0] == 'public_justification_form'


def test_utc_date_converte_texto_para_data_utc():
    from datetime import datetime, timezone
    from controllers.aoe_crud_controller import utc_date
    assert utc_date("2026-10-01") == datetime(2026, 10, 1, tzinfo=timezone.utc)


def test_utc_date_rejeita_formato_invalido():
    from controllers.aoe_crud_controller import utc_date
    with pytest.raises(ValueError):
        utc_date("01/10/2026")


def test_build_document_attendance_preserva_data():
    from controllers.aoe_crud_controller import build_document
    doc = build_document("attendance", {"enrollment_id": "652f1b2c3d4e5f6a7b8c9d0e", "date": "2026-10-01", "status": "ABSENT"}, "652f1b2c3d4e5f6a7b8c9d0f")
    assert doc["date"] is not None


class _FakeCollection:
    def __init__(self):
        self.pipelines = []

    def aggregate(self, pipeline):
        self.pipelines.append(pipeline)
        return []

    def count_documents(self, query):
        return 0


class _FakeDB:
    def __init__(self):
        self.attendance_records = _FakeCollection()
        self.students = _FakeCollection()
        self.guardians = _FakeCollection()


def test_dashboard_filtra_turma_por_objectid():
    from datetime import datetime, timezone
    from bson import ObjectId
    from models.saa_model import SAARepository
    repository = SAARepository.__new__(SAARepository)
    repository.db = _FakeDB()
    class_id = "652f1b2c3d4e5f6a7b8c9d0e"
    now = datetime.now(timezone.utc)
    repository.dashboard(now, now, class_id=class_id)
    filtro = [stage["$match"] for stage in repository.db.attendance_records.pipelines[0] if "$match" in stage and "class._id" in stage["$match"]]
    assert filtro == [{"class._id": ObjectId(class_id)}]


def test_dashboard_turma_invalida_retorna_400():
    from werkzeug.exceptions import BadRequest
    from datetime import datetime, timezone
    from controllers.dashboard_controller import get_dashboard_data
    from models.saa_model import SAARepository
    from app import app
    repository = SAARepository.__new__(SAARepository)
    repository.db = _FakeDB()
    with app.test_request_context():
        with pytest.raises(BadRequest):
            get_dashboard_data({"class_id": "nao-e-um-id"}, repository)
