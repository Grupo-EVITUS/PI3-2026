from datetime import datetime, timedelta, timezone


def day(offset):
    return (datetime.now(timezone.utc) - timedelta(days=offset)).strftime("%Y-%m-%d")


def register(client, student_id, offset):
    response = client.post("/absences", data={"student_id": str(student_id), "date": day(offset)})
    assert response.status_code == 200


def justify_first(client, db, student_id):
    token = db.email_notifications.find_one({"student_id": student_id})["justification_url"].rsplit("/", 1)[1]
    assert client.post(f"/justify/{token}", data={"reason": "DOENCA"}).status_code == 200


def build_scenario(client, seed):
    db = seed["db"]
    register(client, seed["student_id"], 1)
    register(client, seed["student_id"], 2)
    register(client, seed["other_student_id"], 1)
    justify_first(client, db, seed["student_id"])
    enrollment = db.enrollments.find_one({"student_id": seed["other_student_id"]})
    db.attendance_records.insert_one({"enrollment_id": enrollment["_id"], "date": datetime.strptime(day(3), "%Y-%m-%d").replace(tzinfo=timezone.utc), "status": "PRESENT"})
    # Fora do período padrão (últimos 30 dias): não deve entrar nos indicadores.
    db.attendance_records.insert_one({"enrollment_id": enrollment["_id"], "date": datetime.strptime(day(60), "%Y-%m-%d").replace(tzinfo=timezone.utc), "status": "ABSENT"})


def test_indicadores_gerenciais(client, seed):
    build_scenario(client, seed)
    data = client.get("/api/dashboard").get_json()

    assert data["totals"] == {"students": 3, "guardians": 1}
    assert data["range"] == {"start": day(29), "end": day(0)}
    overall = data["overall"]
    assert overall["absence_occurrences"] == 3
    assert overall["distinct_absent_students"] == 2
    assert overall["pending_occurrences"] == 2
    assert overall["responded_occurrences"] == 1
    assert overall["presence_percent"] == 25.0

    by_class = {c["class_name"]: c for c in data["classes"]}
    assert by_class["6º A"]["absence_occurrences"] == 2
    assert (by_class["6º A"]["pending_occurrences"], by_class["6º A"]["responded_occurrences"]) == (1, 1)
    assert (by_class["7º B"]["pending_occurrences"], by_class["7º B"]["responded_occurrences"]) == (1, 0)


def test_ausencias_por_periodo(client, seed):
    build_scenario(client, seed)
    trends = client.get("/api/dashboard").get_json()["absence_trends"]
    daily = {item["period"]: item["absence_occurrences"] for item in trends["daily"]}
    assert daily == {day(2): 1, day(1): 2}
    assert sum(item["absence_occurrences"] for item in trends["monthly"]) == 3
    assert sum(item["absence_occurrences"] for item in trends["yearly"]) == 3


def test_filtros_de_turma_e_periodo(client, seed):
    build_scenario(client, seed)
    data = client.get(f"/api/dashboard?class_id={seed['other_class_id']}").get_json()
    assert [c["class_name"] for c in data["classes"]] == ["7º B"]
    assert data["overall"]["absence_occurrences"] == 1

    data = client.get(f"/api/dashboard?start={day(70)}&end={day(50)}").get_json()
    assert data["overall"]["absence_occurrences"] == 1
    assert data["overall"]["pending_occurrences"] == 1

    assert client.get("/api/dashboard?class_id=invalido").status_code == 400
    assert client.get(f"/api/dashboard?start={day(0)}&end={day(5)}").status_code == 400


def test_pagina_do_dashboard(client, seed):
    build_scenario(client, seed)
    response = client.get("/dashboard")
    html = response.get_data(as_text=True)
    assert response.status_code == 200
    for text in ("Alunos cadastrados", "Responsáveis cadastrados", "Justificativas recebidas", "Ocorrências pendentes", "Ocorrências respondidas", "Ausências por turma", "Ocorrências pendentes e respondidas"):
        assert text in html
    assert f'value="{day(29)}"' in html


def test_dashboard_vazio(client, seed):
    data = client.get("/api/dashboard").get_json()
    assert data["classes"] == []
    assert data["overall"]["pending_occurrences"] == 0
    assert client.get("/dashboard").status_code == 200
