from datetime import datetime, timedelta, timezone
import re

import pytest

import app as app_module
from models.saa_model import SAARepository
from services.email_sender import EmailSendError


@pytest.fixture
def outbox(monkeypatch):
    sent = []
    monkeypatch.setattr(app_module, "send_email", lambda to, subject, body: sent.append({"to": to, "subject": subject, "body": body}))
    return sent


@pytest.fixture
def user(seed):
    repository = SAARepository.__new__(SAARepository)
    repository.db = seed["db"]
    user_id = repository.create_internal_user("Fernanda Lima", "Fernanda@Escola.com", "senha-antiga", "COORDINATION")
    return {"id": user_id, "repo": repository, "db": seed["db"]}


def anonymous():
    return app_module.app.test_client()


def request_reset(client, email="fernanda@escola.com"):
    return client.post("/forgot-password", data={"email": email})


def token_from(mail):
    return re.search(r"/reset-password/([\w-]+)", mail["body"]).group(1)


def test_login_tem_link_para_recuperar_senha(seed):
    html = anonymous().get("/login").get_data(as_text=True)
    assert "Esqueceu a senha?" in html and "/forgot-password" in html


def test_solicitacao_gera_token_e_envia_email(user, outbox):
    response = request_reset(anonymous(), "  FERNANDA@escola.com ")
    assert response.status_code == 200 and "Se o e-mail estiver cadastrado" in response.get_data(as_text=True)
    assert len(outbox) == 1 and outbox[0]["to"] == "fernanda@escola.com"
    token = token_from(outbox[0])
    reset = user["db"].password_resets.find_one({"user_id": user["id"]})
    assert reset["token_hash"] != token and len(reset["token_hash"]) == 64  # só o hash é salvo
    assert reset["expires_at"] - reset["created_at"] == timedelta(hours=1)


def test_email_desconhecido_tem_a_mesma_resposta(user, outbox):
    known = request_reset(anonymous()).get_data(as_text=True)
    unknown = request_reset(anonymous(), "ninguem@escola.com").get_data(as_text=True)
    assert known == unknown
    assert len(outbox) == 1


def test_usuario_inativo_nao_recebe_link(user, outbox):
    user["db"].users.update_one({"_id": user["id"]}, {"$set": {"active": False}})
    request_reset(anonymous())
    assert outbox == []


def test_redefinicao_completa(user, outbox):
    client = anonymous()
    request_reset(client)
    token = token_from(outbox[0])
    assert client.get(f"/reset-password/{token}").status_code == 200

    response = client.post(f"/reset-password/{token}", data={"password": "nova-senha-1", "password_confirmation": "outra"})
    assert response.status_code == 400 and "As senhas não coincidem." in response.get_data(as_text=True)
    response = client.post(f"/reset-password/{token}", data={"password": "curta", "password_confirmation": "curta"})
    assert response.status_code == 400

    response = client.post(f"/reset-password/{token}", data={"password": "nova-senha-1", "password_confirmation": "nova-senha-1"})
    assert response.status_code == 302 and response.headers["Location"].endswith("/login")
    assert "Senha redefinida" in client.get("/login").get_data(as_text=True)

    assert user["repo"].authenticate_user("fernanda@escola.com", "nova-senha-1")
    assert not user["repo"].authenticate_user("fernanda@escola.com", "senha-antiga")
    login = client.post("/login", data={"email": "fernanda@escola.com", "password": "nova-senha-1"})
    assert login.status_code == 302 and login.headers["Location"].endswith("/dashboard")

    # Uso único.
    assert anonymous().get(f"/reset-password/{token}").status_code == 410
    assert anonymous().post(f"/reset-password/{token}", data={"password": "x" * 10, "password_confirmation": "x" * 10}).status_code == 410


def test_token_expirado_ou_invalido(user, outbox):
    request_reset(anonymous())
    token = token_from(outbox[0])
    user["db"].password_resets.update_one({}, {"$set": {"expires_at": datetime.now(timezone.utc) - timedelta(minutes=1)}})
    response = anonymous().get(f"/reset-password/{token}")
    assert response.status_code == 410 and "expirou" in response.get_data(as_text=True)
    assert anonymous().get("/reset-password/token-inventado").status_code == 410


def test_novo_pedido_invalida_o_link_anterior(user, outbox):
    request_reset(anonymous())
    request_reset(anonymous())
    first, second = token_from(outbox[0]), token_from(outbox[1])
    assert anonymous().get(f"/reset-password/{first}").status_code == 410
    assert anonymous().get(f"/reset-password/{second}").status_code == 200


def test_limite_de_pedidos_por_hora(user, outbox):
    for _ in range(5):
        response = request_reset(anonymous())
        assert response.status_code == 200
    assert len(outbox) == SAARepository.PASSWORD_RESET_LIMIT_PER_HOUR


def test_redefinir_senha_encerra_sessoes_abertas(user, outbox):
    logged = anonymous()
    logged.post("/login", data={"email": "fernanda@escola.com", "password": "senha-antiga"})
    assert logged.get("/occurrences").status_code == 200

    request_reset(anonymous())
    anonymous().post(f"/reset-password/{token_from(outbox[0])}", data={"password": "nova-senha-1", "password_confirmation": "nova-senha-1"})
    response = logged.get("/occurrences")
    assert response.status_code == 302 and "/login" in response.headers["Location"]


def test_link_usa_endereco_publico_configurado(user, outbox, monkeypatch):
    monkeypatch.setattr(app_module, "APP_BASE_URL", "https://saa.escola.com.br")
    anonymous().post("/forgot-password", data={"email": "fernanda@escola.com"}, headers={"Host": "site-malicioso.example"})
    assert "https://saa.escola.com.br/reset-password/" in outbox[0]["body"]
    assert "site-malicioso" not in outbox[0]["body"]


def test_falha_no_envio_nao_muda_a_resposta(user, monkeypatch):
    def broken(*args):
        raise EmailSendError("SMTP fora do ar")
    monkeypatch.setattr(app_module, "send_email", broken)
    response = request_reset(anonymous())
    assert response.status_code == 200 and "Se o e-mail estiver cadastrado" in response.get_data(as_text=True)


def test_email_obrigatorio(seed):
    assert anonymous().post("/forgot-password", data={"email": ""}).status_code == 400
