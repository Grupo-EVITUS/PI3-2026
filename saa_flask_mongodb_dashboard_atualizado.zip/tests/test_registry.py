from datetime import datetime, timezone

import pytest

import app as app_module
from models.saa_model import SAARepository


def student_form(**overrides):
    data = {"name": "Daniela Rocha", "school_id": "M100", "birth_date": "2014-05-20"}
    data.update(overrides)
    return data


def guardian_form(**overrides):
    data = {"name": "Eduardo Rocha", "email": "Eduardo@Exemplo.com", "phone": "11987654321", "relationship": "PAI", "receives_absence_notifications": "on"}
    data.update(overrides)
    return data


@pytest.fixture
def admin_client(login_as):
    return login_as("ADMIN")


# ---- Alunos (#38) e relacionamento aluno-turma (#41) ----

def test_cadastro_de_aluno_cria_matricula_na_turma(client, seed):
    db = seed["db"]
    response = client.post("/students", data=student_form(class_id=str(seed["class_id"])))
    assert response.status_code == 302
    student = db.students.find_one({"school_id": "M100"})
    assert response.headers["Location"].endswith(f"/students/{student['_id']}")
    assert student["birth_date"].strftime("%Y-%m-%d") == "2014-05-20"
    enrollment = db.enrollments.find_one({"student_id": student["_id"]})
    assert enrollment["class_id"] == seed["class_id"] and enrollment["academic_period_id"] == "2026"

    page = client.get(response.headers["Location"]).get_data(as_text=True)
    assert "Aluno cadastrado com sucesso." in page and "Daniela Rocha" in page
    listing = client.get("/students").get_data(as_text=True)
    assert "<b>Daniela Rocha</b>" in listing and "20/05/2014" in listing


@pytest.mark.parametrize("overrides, message", [
    ({"birth_date": ""}, "Data de nascimento é obrigatória"),
    ({"birth_date": "2999-01-01"}, "não pode estar no futuro"),
    ({"name": "Daniela"}, "nome completo"),
    ({"school_id": " "}, "Matrícula é obrigatório"),
    ({"class_id": ""}, "Turma é obrigatório"),
    ({"class_id": "652f1b2c3d4e5f6a7b8c9d0e"}, "Turma não encontrada"),
])
def test_validacao_do_cadastro_de_aluno(client, seed, overrides, message):
    data = student_form(class_id=str(seed["class_id"]))
    data.update(overrides)
    response = client.post("/students", data=data)
    assert response.status_code == 400
    assert message in response.get_data(as_text=True)
    assert seed["db"].students.count_documents({"school_id": "M100"}) == 0


def test_matricula_duplicada(client, seed):
    response = client.post("/students", data=student_form(school_id="M001", class_id=str(seed["class_id"])))
    assert response.status_code == 400
    assert "Já existe um aluno com esta matrícula." in response.get_data(as_text=True)


def test_alterar_aluno_e_trocar_de_turma(client, seed):
    db = seed["db"]
    response = client.post(f"/students/{seed['student_id']}", data=student_form(name="Ana Souza Lima", school_id="M001", class_id=str(seed["other_class_id"])))
    assert response.status_code == 302
    assert db.students.find_one({"_id": seed["student_id"]})["name"] == "Ana Souza Lima"
    enrollments = list(db.enrollments.find({"student_id": seed["student_id"]}))
    assert len(enrollments) == 1 and enrollments[0]["class_id"] == seed["other_class_id"]


def test_aluno_inexistente(client, seed):
    assert client.get("/students/652f1b2c3d4e5f6a7b8c9d0e").status_code == 404
    assert client.get("/students/invalido").status_code == 404


# ---- Responsáveis (#39) e relacionamento aluno-responsável (#41) ----

def test_cadastro_de_responsavel_com_vinculo(client, seed):
    db = seed["db"]
    response = client.post("/guardians", data=guardian_form(student_id=str(seed["other_student_id"])))
    assert response.status_code == 302
    guardian = db.guardians.find_one({"email_normalized": "eduardo@exemplo.com"})
    assert guardian["phone"] == "(11) 98765-4321"
    link = db.student_guardians.find_one({"guardian_id": guardian["_id"]})
    assert link["student_id"] == seed["other_student_id"] and link["relationship"] == "PAI" and link["active"] is True
    assert "Bruno Lima" in client.get("/guardians").get_data(as_text=True)
    assert "Bruno Lima" in client.get(f"/guardians/{guardian['_id']}").get_data(as_text=True)


def test_cadastro_de_responsavel_sem_aluno(client, seed):
    response = client.post("/guardians", data=guardian_form(relationship=""))
    assert response.status_code == 302
    assert seed["db"].student_guardians.count_documents({}) == 1  # só o vínculo do seed


@pytest.mark.parametrize("overrides, message", [
    ({"email": "sem-arroba"}, "e-mail válido"),
    ({"phone": "1234"}, "Telefone deve ter DDD"),
    ({"name": ""}, "Nome do responsável é obrigatório"),
    ({"email": "CARLOS@exemplo.com"}, "Já existe um responsável com este e-mail."),
])
def test_validacao_do_cadastro_de_responsavel(client, seed, overrides, message):
    response = client.post("/guardians", data=guardian_form(**overrides))
    assert response.status_code == 400
    assert message in response.get_data(as_text=True)


def test_vincular_desvincular_e_responsavel_principal(client, seed):
    db = seed["db"]
    url = f"/students/{seed['student_id']}/guardians"
    client.post(url, data=guardian_form(is_primary="on"))
    new_guardian = db.guardians.find_one({"email_normalized": "eduardo@exemplo.com"})
    links = {l["guardian_id"]: l for l in db.student_guardians.find({"student_id": seed["student_id"]})}
    assert links[new_guardian["_id"]]["is_primary"] is True
    assert links[seed["guardian_id"]]["is_primary"] is False

    page = client.get(f"/students/{seed['student_id']}").get_data(as_text=True)
    assert "Eduardo Rocha" in page and "Carlos Souza" in page and "Responsável vinculado ao aluno." in page

    client.post(f"{url}/{seed['guardian_id']}/remove")
    repository = SAARepository.__new__(SAARepository)
    repository.db = db
    emails = [g["email"] for g in repository.student_guardians(seed["student_id"], only_notifiable=True)]
    assert emails == ["eduardo@exemplo.com"]

    # Revincular o responsável já cadastrado, sem receber avisos.
    client.post(url, data={"guardian_id": str(seed["guardian_id"]), "relationship": "MAE"})
    emails = [g["email"] for g in repository.student_guardians(seed["student_id"], only_notifiable=True)]
    assert emails == ["eduardo@exemplo.com"]
    assert db.student_guardians.count_documents({"student_id": seed["student_id"], "active": True}) == 2


def test_cadastro_pelo_aluno_com_email_duplicado_mostra_erro(client, seed):
    response = client.post(f"/students/{seed['student_id']}/guardians", data=guardian_form(email="carlos@exemplo.com"), follow_redirects=True)
    assert "Já existe um responsável com este e-mail" in response.get_data(as_text=True)


# ---- Turmas (#40) ----

def class_form(**overrides):
    data = {"name": "9º C", "code": "9c", "academic_period_id": "2026", "grade": "9º ano", "shift": "AFTERNOON"}
    data.update(overrides)
    return data


def test_cadastro_alteracao_e_associacao_de_turma(client, seed):
    db = seed["db"]
    response = client.post("/classes", data=class_form())
    assert response.status_code == 302
    school_class = db.classes.find_one({"code": "9C"})
    assert school_class["shift"] == "AFTERNOON"

    assert client.post(f"/classes/{school_class['_id']}", data=class_form(name="9º C Tarde")).status_code == 302
    assert db.classes.find_one({"_id": school_class["_id"]})["name"] == "9º C Tarde"

    client.post(f"/classes/{school_class['_id']}/students", data={"student_id": str(seed["student_id"])})
    enrollment = db.enrollments.find_one({"student_id": seed["student_id"], "active": True})
    assert enrollment["class_id"] == school_class["_id"]
    page = client.get(f"/classes/{school_class['_id']}").get_data(as_text=True)
    assert "Ana Souza" in page and "Aluno associado à turma." in page

    # Período não pode mudar com alunos matriculados.
    response = client.post(f"/classes/{school_class['_id']}", data=class_form(academic_period_id="2027"))
    assert response.status_code == 400

    # Aluno sem matrícula no período ganha uma nova.
    client.post(f"/classes/{school_class['_id']}/students", data={"student_id": str(seed["no_enrollment_id"])})
    assert db.enrollments.find_one({"student_id": seed["no_enrollment_id"]})["class_id"] == school_class["_id"]


@pytest.mark.parametrize("overrides, message", [
    ({"code": "6a"}, "Já existe uma turma com este código"),
    ({"shift": ""}, "Selecione o turno"),
    ({"academic_period_id": "26"}, "Período letivo deve ser o ano"),
    ({"name": ""}, "Nome da turma é obrigatório"),
])
def test_validacao_do_cadastro_de_turma(client, seed, overrides, message):
    response = client.post("/classes", data=class_form(**overrides))
    assert response.status_code == 400
    assert message in response.get_data(as_text=True)


# ---- Usuários (#36) e consulta de usuários (#37) ----

def test_somente_admin_gerencia_usuarios(client, seed):
    assert client.get("/users").status_code == 403
    assert client.post("/users", data={}).status_code == 403


def test_cadastro_e_busca_de_usuarios(admin_client, seed):
    db = seed["db"]
    data = {"name": "Fernanda Coordenação", "email": "Fernanda@Escola.com", "profile": "COORDINATION", "password": "segura123", "password_confirmation": "segura123"}
    response = admin_client.post("/users", data=data)
    assert response.status_code == 302
    repository = SAARepository.__new__(SAARepository)
    repository.db = db
    assert repository.authenticate_user("fernanda@escola.com", "segura123")["profile"] == "COORDINATION"

    page = admin_client.get("/users").get_data(as_text=True)
    assert "cadastrado com sucesso" in page and "Fernanda Coordenação" in page
    assert "Fernanda" in admin_client.get("/users?q=fern").get_data(as_text=True)
    assert "Nenhum usuário encontrado" in admin_client.get("/users?q=zzz").get_data(as_text=True)

    response = admin_client.post("/users", data=data)
    assert response.status_code == 400 and "Já existe um usuário com este e-mail." in response.get_data(as_text=True)


@pytest.mark.parametrize("overrides, message", [
    ({"password_confirmation": "outra-senha"}, "As senhas não coincidem."),
    ({"password": "curta", "password_confirmation": "curta"}, "pelo menos 8 caracteres"),
    ({"profile": "ROOT"}, "Selecione o perfil."),
])
def test_validacao_do_cadastro_de_usuario(admin_client, seed, overrides, message):
    data = {"name": "Gabriel", "email": "gabriel@escola.com", "profile": "AOE", "password": "segura123", "password_confirmation": "segura123"}
    data.update(overrides)
    response = admin_client.post("/users", data=data)
    html = response.get_data(as_text=True)
    assert response.status_code == 400 and message in html
    assert "segura123" not in html  # senha nunca volta para a página


# ---- Fluxo completo: cadastros pela tela alimentam o registro de ausência ----

def test_aluno_e_responsavel_cadastrados_pela_tela_recebem_aviso(client, seed):
    db = seed["db"]
    client.post("/students", data=student_form(class_id=str(seed["class_id"])))
    student = db.students.find_one({"school_id": "M100"})
    client.post(f"/students/{student['_id']}/guardians", data=guardian_form())
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    assert client.post("/absences", data={"student_id": str(student["_id"]), "date": today}).status_code == 200
    notification = db.email_notifications.find_one({"student_id": student["_id"]})
    assert notification["recipient_email"] == "eduardo@exemplo.com" and notification["status"] == "SENT"


def test_rotas_de_cadastro_exigem_login(seed):
    anonymous = app_module.app.test_client()
    for path in ("/students", "/guardians", "/classes", "/users"):
        assert anonymous.get(path).status_code == 302
