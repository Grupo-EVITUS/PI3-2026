from datetime import datetime, timezone
from functools import wraps
from flask import Flask, abort, jsonify, redirect, render_template, request, session, url_for
from bson import ObjectId
from pymongo.errors import DuplicateKeyError
from config import SECRET_KEY
from controllers.dashboard_controller import get_dashboard_data
from controllers.aoe_crud_controller import COLLECTIONS, build_document, duplicate_error_message, validate_document
from models.saa_model import SAARepository

app = Flask(__name__, template_folder="views/templates", static_folder="views/static")
app.config["SECRET_KEY"] = SECRET_KEY


def repo():
    return SAARepository()


def json_safe(value):
    if isinstance(value, ObjectId):
        return str(value)
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, list):
        return [json_safe(item) for item in value]
    if isinstance(value, dict):
        return {key: json_safe(item) for key, item in value.items()}
    return value


def aoe_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session or session.get("profile") not in {"AOE", "COORDINATION", "ADMIN"}:
            return redirect(url_for("aoe_login", next=request.full_path))
        return view(*args, **kwargs)
    return wrapped


@app.get("/")
def index():
    return redirect(url_for("dashboard"))


@app.route("/login", methods=["GET", "POST"])
def aoe_login():
    if request.method == "GET":
        return render_template("aoe_login.html")
    email = request.form.get("email", "")
    password = request.form.get("password", "")
    r = repo()
    try:
        user = r.authenticate_user(email, password, allowed_profiles=["AOE", "COORDINATION", "ADMIN"])
    finally:
        r.close()
    if not user:
        return render_template("aoe_login.html", error="E-mail ou senha inválidos."), 401
    session.clear()
    session["user_id"] = str(user["_id"])
    session["user_name"] = user.get("name", "Usuário")
    session["profile"] = user.get("profile")
    return redirect(request.form.get("next") or url_for("dashboard"))


@app.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("aoe_login"))


@app.get("/dashboard")
@aoe_required
def dashboard():
    r = repo()
    try:
        data = get_dashboard_data(request.args, r)
        classes = r.list_classes(request.args.get("period_id") or None)
        return render_template("dashboard.html", data=data, classes=classes, filters=request.args, user_name=session.get("user_name"))
    finally:
        r.close()


@app.get("/api/dashboard")
@aoe_required
def dashboard_api():
    return jsonify(get_dashboard_data(request.args))


@app.get("/students")
@aoe_required
def students():
    r = repo()
    try:
        return render_template("students.html", students=r.list_students(), user_name=session.get("user_name"))
    finally:
        r.close()


@app.post("/attendance")
@aoe_required
def create_attendance():
    payload = request.form or request.get_json(silent=True) or {}
    required = ("enrollment_id", "date", "status")
    if any(not payload.get(key) for key in required):
        abort(400, description="enrollment_id, date e status são obrigatórios.")
    if payload["status"] not in {"PRESENT", "ABSENT", "NOT_REGISTERED", "EXCUSED"}:
        abort(400, description="Situação de frequência inválida.")
    r = repo()
    try:
        r.create_attendance({"enrollment_id": r.object_id(payload["enrollment_id"]), "date": datetime.strptime(payload["date"], "%Y-%m-%d").replace(tzinfo=timezone.utc), "status": payload["status"], "registered_by": r.object_id(session["user_id"])})
    except Exception as exc:
        if exc.__class__.__name__ == "DuplicateKeyError":
            abort(409, description="Já existe frequência para esta matrícula e data.")
        raise
    finally:
        r.close()
    return redirect(url_for("dashboard"))


@app.get("/justify/<token>")
def public_justification_form(token):
    r = repo()
    try:
        link = r.find_justification_link(token)
        if not link:
            abort(410, description="Este link é inválido, expirou ou já foi utilizado.")
        return render_template("justification.html", token=token)
    finally:
        r.close()


@app.post("/justify/<token>")
def submit_public_justification(token):
    reason = request.form.get("reason", "").strip()
    explanation = request.form.get("explanation", "").strip()
    if not reason or (reason == "OTHER" and not explanation):
        abort(400, description="Informe o motivo e a explicação quando selecionar Outro.")
    r = repo()
    try:
        success, message = r.submit_public_justification(token, reason, explanation)
    finally:
        r.close()
    if not success:
        abort(410, description=message)
    return render_template("justification_success.html")


@app.get("/api/<resource>")
@aoe_required
def crud_list(resource):
    if resource not in COLLECTIONS:
        abort(404, description="Recurso não encontrado.")
    r = repo()
    try:
        query = {"active": True} if resource != "attendance" else {}
        return jsonify([json_safe(item) for item in r.list_collection(COLLECTIONS[resource], query)])
    finally:
        r.close()


@app.post("/api/<resource>")
@aoe_required
def crud_create(resource):
    if resource not in COLLECTIONS:
        abort(404, description="Recurso não encontrado.")
    payload = request.get_json(silent=True) or request.form.to_dict()
    r = repo()
    try:
        document = build_document(resource, payload, session["user_id"])
        validate_document(r, resource, document)
        identifier = r.insert_document(COLLECTIONS[resource], document)
        return jsonify({"id": str(identifier), "message": "Registro criado com sucesso."}), 201
    except ValueError as exc:
        abort(400, description=str(exc))
    except DuplicateKeyError:
        abort(409, description=duplicate_error_message(resource))
    finally:
        r.close()


@app.get("/api/<resource>/<identifier>")
@aoe_required
def crud_get(resource, identifier):
    if resource not in COLLECTIONS:
        abort(404, description="Recurso não encontrado.")
    r = repo()
    try:
        item = r.find_one(COLLECTIONS[resource], identifier)
        if not item:
            abort(404, description="Registro não encontrado.")
        return jsonify(json_safe(item))
    except ValueError as exc:
        abort(400, description=str(exc))
    finally:
        r.close()


@app.patch("/api/<resource>/<identifier>")
@aoe_required
def crud_update(resource, identifier):
    if resource not in COLLECTIONS:
        abort(404, description="Recurso não encontrado.")
    changes = request.get_json(silent=True) or request.form.to_dict()
    allowed = {"name", "school_id", "code", "academic_period_id", "grade", "shift", "email", "phone", "active", "start_date", "end_date", "status"}
    changes = {key: value for key, value in changes.items() if key in allowed}
    if "email" in changes:
        changes["email_normalized"] = changes["email"].strip().lower()
    if "start_date" in changes:
        changes["start_date"] = __import__("controllers.aoe_crud_controller", fromlist=["utc_date"]).utc_date(changes["start_date"])
    if "end_date" in changes:
        changes["end_date"] = __import__("controllers.aoe_crud_controller", fromlist=["utc_date"]).utc_date(changes["end_date"])
    r = repo()
    try:
        if resource == "attendance" and "status" in changes and changes["status"] not in {"PRESENT", "ABSENT", "NOT_REGISTERED", "EXCUSED"}:
            abort(400, description="Status de frequência inválido.")
        if not r.update_document(COLLECTIONS[resource], identifier, changes):
            abort(404, description="Registro não encontrado.")
        return jsonify({"message": "Registro atualizado com sucesso."})
    except ValueError as exc:
        abort(400, description=str(exc))
    except DuplicateKeyError:
        abort(409, description=duplicate_error_message(resource))
    finally:
        r.close()


@app.delete("/api/<resource>/<identifier>")
@aoe_required
def crud_delete(resource, identifier):
    if resource not in COLLECTIONS:
        abort(404, description="Recurso não encontrado.")
    if resource in {"attendance", "enrollments"}:
        abort(409, description="Registros históricos de frequência e matrícula não devem ser apagados; arquive-os ou encerre sua vigência.")
    r = repo()
    try:
        if not r.archive_document(COLLECTIONS[resource], identifier):
            abort(404, description="Registro não encontrado.")
        return jsonify({"message": "Registro arquivado com sucesso."})
    except ValueError as exc:
        abort(400, description=str(exc))
    finally:
        r.close()


if __name__ == "__main__":
    SAARepository().ensure_indexes()
    app.run(host="0.0.0.0", port=5000, debug=True)
