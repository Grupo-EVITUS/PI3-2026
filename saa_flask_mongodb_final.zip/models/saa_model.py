from datetime import datetime, timezone
import hashlib
import secrets
from pymongo import ASCENDING, DESCENDING, MongoClient
from pymongo.errors import DuplicateKeyError
from werkzeug.security import check_password_hash, generate_password_hash
from config import MONGO_DB, MONGO_URI
from bson import ObjectId


def utcnow():
    return datetime.now(timezone.utc)


class SAARepository:
    def __init__(self, uri=MONGO_URI, database=MONGO_DB):
        self.client = MongoClient(uri, serverSelectionTimeoutMS=3000)
        self.db = self.client[database]

    def close(self):
        self.client.close()

    @staticmethod
    def object_id(value):
        try:
            return ObjectId(value)
        except Exception:
            raise ValueError("Identificador MongoDB inválido.")

    def find_one(self, collection, identifier):
        return self.db[collection].find_one({"_id": self.object_id(identifier)})

    def list_collection(self, collection, query=None, limit=100):
        return list(self.db[collection].find(query or {}).sort("created_at", DESCENDING).limit(limit))

    def insert_document(self, collection, document):
        now = utcnow()
        document.setdefault("active", True)
        document.setdefault("created_at", now)
        document.setdefault("updated_at", now)
        return self.db[collection].insert_one(document).inserted_id

    def update_document(self, collection, identifier, changes):
        changes["updated_at"] = utcnow()
        result = self.db[collection].update_one({"_id": self.object_id(identifier)}, {"$set": changes})
        return result.matched_count == 1

    def archive_document(self, collection, identifier):
        return self.update_document(collection, identifier, {"active": False, "archived_at": utcnow()})

    def validate_student(self, document):
        if not document.get("name", "").strip():
            raise ValueError("Nome do aluno é obrigatório.")

    def validate_class(self, document):
        if not document.get("name", "").strip() or not document.get("academic_period_id"):
            raise ValueError("Nome da turma e período letivo são obrigatórios.")

    def validate_guardian(self, document):
        if not document.get("name", "").strip() or "@" not in document.get("email", ""):
            raise ValueError("Nome e e-mail válido do responsável são obrigatórios.")
        document["email_normalized"] = document["email"].strip().lower()

    def validate_enrollment(self, document):
        for field in ("student_id", "class_id", "academic_period_id"):
            if not document.get(field):
                raise ValueError(f"{field} é obrigatório.")

    def validate_attendance(self, document):
        if document.get("status") not in {"PRESENT", "ABSENT", "NOT_REGISTERED", "EXCUSED"}:
            raise ValueError("Status de frequência inválido.")
        if not document.get("enrollment_id") or not document.get("date"):
            raise ValueError("Matrícula e data são obrigatórias.")

    def ensure_indexes(self):
        self.db.students.create_index([("school_id", ASCENDING)], unique=True, sparse=True)
        self.db.classes.create_index([("academic_period_id", ASCENDING), ("code", ASCENDING)], unique=True)
        self.db.enrollments.create_index([("student_id", ASCENDING), ("academic_period_id", ASCENDING)], unique=True)
        self.db.enrollments.create_index([("class_id", ASCENDING), ("academic_period_id", ASCENDING)])
        self.db.attendance_records.create_index(
            [("enrollment_id", ASCENDING), ("date", ASCENDING)], unique=True
        )
        self.db.attendance_records.create_index([("date", ASCENDING), ("status", ASCENDING)])
        self.db.justification_reasons.create_index("code", unique=True)
        self.db.justifications.create_index([("attendance_id", ASCENDING)], unique=True)
        self.db.justifications.create_index([("status", ASCENDING), ("submitted_at", DESCENDING)])
        self.db.guardians.create_index("email_normalized", unique=True, sparse=True)
        self.db.student_guardians.create_index([("student_id", ASCENDING), ("guardian_id", ASCENDING)], unique=True)
        self.db.email_notifications.create_index([("attendance_id", ASCENDING), ("guardian_id", ASCENDING)])
        self.db.email_notifications.create_index([("status", ASCENDING), ("attempted_at", DESCENDING)])
        self.db.users.create_index("email_normalized", unique=True)
        self.db.justification_links.create_index("token_hash", unique=True)
        self.db.justification_links.create_index([("expires_at", ASCENDING), ("used_at", ASCENDING)])
        self.db.attendance_policies.create_index([("academic_period_id", ASCENDING), ("scope", ASCENDING)], unique=True)

    def dashboard(self, start, end, class_id=None, period_id=None, shift=None):
        match = {"date": {"$gte": start, "$lte": end}, "status": {"$in": ["PRESENT", "ABSENT"]}}
        pipeline = [
            {"$match": match},
            {"$lookup": {"from": "enrollments", "localField": "enrollment_id", "foreignField": "_id", "as": "enrollment"}},
            {"$unwind": "$enrollment"},
            {"$lookup": {"from": "classes", "localField": "enrollment.class_id", "foreignField": "_id", "as": "class"}},
            {"$unwind": "$class"},
        ]
        if class_id:
            pipeline.append({"$match": {"class._id": class_id}})
        if period_id:
            pipeline.append({"$match": {"enrollment.academic_period_id": period_id}})
        if shift:
            pipeline.append({"$match": {"class.shift": shift}})

        by_class = pipeline + [{"$group": {
            "_id": {"id": "$class._id", "name": "$class.name"},
            "distinct_absent_students": {"$addToSet": {"$cond": [{"$eq": ["$status", "ABSENT"]}, "$enrollment.student_id", None]}},
            "absence_occurrences": {"$sum": {"$cond": [{"$eq": ["$status", "ABSENT"]}, 1, 0]}},
            "present_count": {"$sum": {"$cond": [{"$eq": ["$status", "PRESENT"]}, 1, 0]}},
            "valid_opportunities": {"$sum": 1},
        }}, {"$sort": {"_id.name": 1}}]
        classes = []
        for item in self.db.attendance_records.aggregate(by_class):
            absent = [x for x in item["distinct_absent_students"] if x is not None]
            classes.append({
                "class_id": item["_id"]["id"], "class_name": item["_id"]["name"],
                "distinct_absent_students": len(absent),
                "absence_occurrences": item["absence_occurrences"],
                "presence_percent": round(item["present_count"] / item["valid_opportunities"] * 100, 2) if item["valid_opportunities"] else 0,
                "present_count": item["present_count"], "valid_opportunities": item["valid_opportunities"],
            })

        overall = {"distinct_absent_students": 0, "absence_occurrences": 0, "present_count": 0, "valid_opportunities": 0}
        distinct = set()
        for item in self.db.attendance_records.aggregate(pipeline + [{"$group": {
            "_id": None,
            "students": {"$addToSet": {"$cond": [{"$eq": ["$status", "ABSENT"]}, "$enrollment.student_id", None]}},
            "absence_occurrences": {"$sum": {"$cond": [{"$eq": ["$status", "ABSENT"]}, 1, 0]}},
            "present_count": {"$sum": {"$cond": [{"$eq": ["$status", "PRESENT"]}, 1, 0]}},
            "valid_opportunities": {"$sum": 1},
        }}]):
            distinct = {x for x in item.get("students", []) if x is not None}
            overall.update({k: item.get(k, 0) for k in ("absence_occurrences", "present_count", "valid_opportunities")})
        overall["distinct_absent_students"] = len(distinct)
        overall["presence_percent"] = round(overall["present_count"] / overall["valid_opportunities"] * 100, 2) if overall["valid_opportunities"] else 0
        return {"classes": classes, "overall": overall}

    def create_attendance(self, document):
        document.setdefault("created_at", utcnow())
        return self.db.attendance_records.insert_one(document).inserted_id

    def list_students(self):
        return list(self.db.students.find({"active": True}, {"name": 1, "school_id": 1}).sort("name", ASCENDING))

    def list_classes(self, period_id=None):
        query = {"active": True}
        if period_id:
            query["academic_period_id"] = period_id
        return list(self.db.classes.find(query).sort("name", ASCENDING))

    def list_pending_justifications(self):
        return list(self.db.justifications.find({"status": "PENDING"}).sort("created_at", DESCENDING))

    def authenticate_user(self, email, password, allowed_profiles=None):
        query = {"email_normalized": email.strip().lower(), "active": True}
        if allowed_profiles:
            query["profile"] = {"$in": allowed_profiles}
        user = self.db.users.find_one(query)
        if not user or not user.get("password_hash") or not check_password_hash(user["password_hash"], password):
            return None
        self.db.users.update_one({"_id": user["_id"]}, {"$set": {"last_login_at": utcnow()}})
        user.pop("password_hash", None)
        return user

    def create_internal_user(self, name, email, password, profile):
        allowed = {"AOE", "COORDINATION", "ADMIN"}
        if profile not in allowed:
            raise ValueError("Perfil inválido. Use AOE, COORDINATION ou ADMIN.")
        if len(password) < 8:
            raise ValueError("A senha deve possuir pelo menos 8 caracteres.")
        now = utcnow()
        return self.db.users.insert_one({
            "name": name.strip(),
            "email": email.strip(),
            "email_normalized": email.strip().lower(),
            "password_hash": generate_password_hash(password),
            "profile": profile,
            "active": True,
            "created_at": now,
            "updated_at": now,
        }).inserted_id

    def find_justification_link(self, raw_token):
        token_hash = hashlib.sha256(raw_token.encode("utf-8")).hexdigest()
        link = self.db.justification_links.find_one({
            "token_hash": token_hash,
            "used_at": {"$exists": False},
            "expires_at": {"$gt": utcnow()},
            "active": True,
        })
        return link

    def create_justification_link(self, attendance_id, guardian_id, expires_at):
        raw_token = secrets.token_urlsafe(32)
        self.db.justification_links.insert_one({
            "token_hash": hashlib.sha256(raw_token.encode("utf-8")).hexdigest(),
            "attendance_id": attendance_id,
            "guardian_id": guardian_id,
            "expires_at": expires_at,
            "active": True,
            "created_at": utcnow(),
        })
        # O token puro só é devolvido para a camada que enviará o e-mail; não é salvo.
        return raw_token

    def submit_public_justification(self, raw_token, reason, explanation):
        link = self.find_justification_link(raw_token)
        if not link:
            return False, "Link inválido, expirado ou já utilizado."
        now = utcnow()
        result = self.db.justifications.update_one(
            {"attendance_id": link["attendance_id"]},
            {"$set": {"attendance_id": link["attendance_id"], "guardian_id": link.get("guardian_id"), "reason": reason, "explanation": explanation, "status": "RESPONDED", "submitted_at": now, "updated_at": now},
             "$setOnInsert": {"created_at": now}},
            upsert=True,
        )
        self.db.justification_links.update_one({"_id": link["_id"], "used_at": {"$exists": False}}, {"$set": {"used_at": now}})
        return True, str(result.upserted_id or link["attendance_id"])
